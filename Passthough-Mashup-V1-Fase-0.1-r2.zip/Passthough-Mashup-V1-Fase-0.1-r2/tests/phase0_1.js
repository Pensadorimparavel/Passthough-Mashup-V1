/*
 * Critérios da Fase 0.1 (cada um só vale se o log mostrar OK; nada é presumido):
 *  A  Dois Workers inicializam, cada um com seu módulo WASM e HEAPU8 acessível.
 *  B  ROM carregada e identificada (título/código do cabeçalho lidos pelo core).
 *  C  runFrame avança exatamente 1 no contador de frames, em cada instância.
 *  D  setKeys/getKeys em ida e volta; escrita/leitura de EWRAM pelo barramento.
 *  E  Framebuffer: dimensões vindas do core, 4 bytes/pixel, e pixels não-zero após 300 frames.
 *  F  Memória independente: sentinelas diferentes no mesmo endereço em A e B.
 *  G  Execução independente: avançar A não altera o contador de B.
 *  P  Desempenho (informativo): ms/frame com 2 instâncias simultâneas, após aquecimento.
 */
const $ = (s) => document.querySelector(s);
const logEl = $("#log");
let workers = [];
let busy = false;
let logText = "";

function log(msg) { logText += msg + "\n"; logEl.textContent = logText; }
function assert(cond, msg) {
  if (!cond) throw new Error(`FALHOU: ${msg}`);
  log(`OK: ${msg}`);
}

function makeWorker() {
  const worker = new Worker(new URL("../src/workers/emulator.worker.js", import.meta.url), { type: "module" });
  let nextId = 1;
  const pending = new Map();
  worker.onmessage = (e) => {
    const m = e.data; const p = pending.get(m.id);
    if (!p) return;
    pending.delete(m.id);
    if (m.ok) p.resolve(m);
    else { const err = new Error(m.error || "erro no worker"); err.code = m.errorCode; p.reject(err); }
  };
  worker.onerror = (e) => {
    for (const p of pending.values()) p.reject(new Error(`worker error: ${e.message}`));
    pending.clear();
  };
  return {
    raw: worker,
    request(type, payload = {}, transfer = []) {
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        worker.postMessage({ id, type, ...payload }, transfer);
      });
    },
    terminate() {
      worker.terminate();
      for (const p of pending.values()) p.reject(new Error("Worker encerrado."));
      pending.clear();
    }
  };
}

async function readFile(input, fallback) {
  const f = input.files?.[0] || fallback;
  if (!f) throw new Error("Selecione uma ROM para o Worker A.");
  return f.arrayBuffer();
}
function stopAll() { workers.forEach((w) => w.terminate()); workers = []; }
const mb = (n) => (n / 1048576).toFixed(1) + " MiB";

async function setup() {
  const bufA = await readFile($("#romA"));
  const bufB = await readFile($("#romB"), $("#romA").files?.[0]);
  const a = makeWorker(), b = makeWorker();
  workers = [a, b];
  const t0 = performance.now();
  const [ra, rb] = await Promise.all([a.request("init"), b.request("init")]);
  log(`Init dos 2 workers: ${(performance.now() - t0).toFixed(0)} ms; memória WASM A=${mb(ra.memoryBytes)} B=${mb(rb.memoryBytes)}; protocolo ${ra.protocolVersion}/${rb.protocolVersion}`);
  assert(a.raw !== b.raw && ra.protocolVersion === 1, "[A] dois Workers distintos, módulos WASM inicializados");
  const [la, lb] = await Promise.all([
    a.request("loadRom", { rom: bufA }, [bufA]),
    b.request("loadRom", { rom: bufB }, [bufB])
  ]);
  log(`Memória WASM após ROM: A=${mb(la.memoryBytes)} B=${mb(lb.memoryBytes)}`);
  return { a, b };
}

async function runTests() {
  const { a, b } = await setup();
  const [ia, ib] = await Promise.all([a.request("gameInfo"), b.request("gameInfo")]);
  log(`A: título="${ia.title}" código="${ia.code}" | B: título="${ib.title}" código="${ib.code}"`);
  assert(ia.title.length > 0 && ib.title.length > 0, "[B] ROM carregada e identificada pelo core em A e B");

  const [fa, fb] = await Promise.all([a.request("runFrame"), b.request("runFrame")]);
  assert(fa.after === fa.before + 1 && fb.after === fb.before + 1, `[C] runFrame avançou exatamente 1 (A ${fa.before}->${fa.after}, B ${fb.before}->${fb.after})`);

  await a.request("setKeys", { keys: 1 });
  assert((await a.request("getKeys")).keys === 1, "[D] máscara de teclas devolvida pelo core");
  await a.request("setKeys", { keys: 0 });
  const EWRAM = 0x02000000;
  await Promise.all([a.request("writeMemory8", { address: EWRAM, value: 0x5a }), b.request("writeMemory8", { address: EWRAM, value: 0xa5 })]);
  const [ma, mbv] = await Promise.all([a.request("readMemory8", { address: EWRAM }), b.request("readMemory8", { address: EWRAM })]);
  assert(ma.value === 0x5a && mbv.value === 0xa5, "[D/F] EWRAM: A leu 0x5A e B leu 0xA5 no mesmo endereço");
  const [ra, rb] = await Promise.all([a.request("rawRead8", { address: EWRAM }), b.request("rawRead8", { address: EWRAM })]);
  log(`Info: rawRead8 EWRAM A=0x${ra.value.toString(16)} B=0x${rb.value.toString(16)} (informativo)`);

  const ca = (await a.request("stats")).frameCounter, cb = (await b.request("stats")).frameCounter;
  await a.request("runFrames", { count: 30 });
  const cb2 = (await b.request("stats")).frameCounter;
  assert(cb2 === cb && (await a.request("stats")).frameCounter === ca + 30, "[G] avançar A em 30 frames não alterou o contador de B");

  await Promise.all([a.request("runFrames", { count: 300 }), b.request("runFrames", { count: 300 })]);
  const [va, vb] = await Promise.all([a.request("framebuffer"), b.request("framebuffer")]);
  log(`Framebuffer A: ${va.width}x${va.height}, ${va.bpp} B/px, não-zero=${va.nonZeroPixels}, cores≈${va.distinctColors}`);
  log(`Framebuffer B: ${vb.width}x${vb.height}, ${vb.bpp} B/px, não-zero=${vb.nonZeroPixels}, cores≈${vb.distinctColors}`);
  assert(va.width === 240 && va.height === 160 && va.byteLength === 240 * 160 * va.bpp && va.bpp === 4, "[E] dimensões 240×160 e 4 B/px reportadas pelo core");
  assert(va.nonZeroPixels > 0 && vb.nonZeroPixels > 0, "[E] há pixels não-zero após 300 frames em A e B");

  // P: aquecimento + medição com os dois rodando juntos
  await Promise.all([a.request("runFrames", { count: 120 }), b.request("runFrames", { count: 120 })]);
  const [pa, pb] = await Promise.all([a.request("runFrames", { count: 600 }), b.request("runFrames", { count: 600 })]);
  const budget = 1000 / 59.7275;
  for (const [n, p] of [["A", pa], ["B", pb]])
    log(`[P] ${n}: 600 frames em ${p.wallMs.toFixed(0)} ms; média ${p.avgMs.toFixed(2)} ms/frame; p95 ${p.p95Ms.toFixed(2)}; máx ${p.maxMs.toFixed(2)}; orçamento ${budget.toFixed(2)} ms; memória ${mb(p.memoryBytes)}`);
  log("\nTESTES A–G CONCLUÍDOS neste navegador. Isto NÃO substitui o teste sustentado nem a validação no Android.");
}

async function probeInvalidRom() {
  const w = makeWorker();
  try {
    await w.request("init");
    try { await w.request("loadRom", { rom: new ArrayBuffer(1 << 20) }); log("Sonda: ROM inválida (1 MiB de zeros) foi ACEITA pelo core."); }
    catch (e) { log(`Sonda: ROM inválida (1 MiB de zeros) REJEITADA (${e.message}, código ${e.code}).`); }
  } finally { w.terminate(); }
}

async function runSustained() {
  const minutes = Math.max(1, Math.min(30, Number($("#minutes").value) || 5));
  const { a, b } = await setup();
  await Promise.all([a.request("runFrames", { count: 120 }), b.request("runFrames", { count: 120 })]);
  const start = performance.now(); let lastReport = start; let acc = [];
  log(`Sustentado: ${minutes} min, 2 workers. Relatório a cada 30 s (média ms/frame; tendência de alta indica estrangulamento térmico/CPU).`);
  while (performance.now() - start < minutes * 60000) {
    const [pa, pb] = await Promise.all([a.request("runFrames", { count: 60 }), b.request("runFrames", { count: 60 })]);
    acc.push(Math.max(pa.avgMs, pb.avgMs));
    if (performance.now() - lastReport >= 30000) {
      const avg = acc.reduce((x, y) => x + y, 0) / acc.length;
      log(`t=${((performance.now() - start) / 1000).toFixed(0)}s  pior-média=${avg.toFixed(2)} ms/frame  p95(A)=${pa.p95Ms.toFixed(2)}  mem A=${mb(pa.memoryBytes)} B=${mb(pb.memoryBytes)}`);
      acc = []; lastReport = performance.now();
    }
  }
  log("Sustentado concluído sem travar. Anote temperatura/comportamento do aparelho manualmente.");
}

function guard(fn) {
  return async () => {
    if (busy) return; busy = true; document.querySelectorAll("button").forEach((x) => (x.disabled = true));
    stopAll(); logText = "";
    try { await fn(); }
    catch (e) { log(`\nERRO: ${e instanceof Error ? e.message : e}`); log("Testes seguintes NÃO foram considerados aprovados."); }
    finally { busy = false; document.querySelectorAll("button").forEach((x) => (x.disabled = false)); }
  };
}
$("#runTests").addEventListener("click", guard(async () => { await runTests(); stopAll(); await probeInvalidRom(); }));
$("#sustained").addEventListener("click", guard(runSustained));
$("#stopWorkers").addEventListener("click", () => { stopAll(); log("Workers encerrados."); });
$("#downloadLog").addEventListener("click", () => {
  const url = URL.createObjectURL(new Blob([logText], { type: "text/plain" }));
  const l = document.createElement("a"); l.href = url; l.download = "phase0_1_log.txt"; l.click(); URL.revokeObjectURL(url);
});
