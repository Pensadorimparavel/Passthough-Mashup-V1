#!/usr/bin/env bash
# Baixa o mGBA 0.10.5 (tag oficial) em external/mgba. Não modifica o upstream.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MGBA_DIR="$ROOT/external/mgba"
TAG="0.10.5"

command -v git >/dev/null || { echo "ERRO: git não encontrado." >&2; exit 1; }
mkdir -p "$ROOT/external" "$ROOT/logs"

if [ ! -d "$MGBA_DIR/.git" ]; then
  git clone --depth 1 --branch "$TAG" https://github.com/mgba-emu/mgba.git "$MGBA_DIR"
fi

DESC="$(git -C "$MGBA_DIR" describe --tags --exact-match 2>/dev/null || true)"
if [ "$DESC" != "$TAG" ]; then
  echo "ERRO: external/mgba não está na tag $TAG (encontrado: '${DESC:-sem tag}')." >&2
  echo "Apague external/mgba e rode novamente." >&2
  exit 1
fi
git -C "$MGBA_DIR" rev-parse HEAD | tee "$ROOT/logs/mgba_commit.txt"
echo "mGBA $TAG pronto em $MGBA_DIR"
