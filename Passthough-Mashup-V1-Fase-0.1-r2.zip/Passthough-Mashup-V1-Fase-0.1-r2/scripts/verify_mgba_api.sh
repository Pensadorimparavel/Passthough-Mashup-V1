#!/usr/bin/env bash
# Confirma, nos headers REAIS do mGBA 0.10.5 clonado, cada símbolo usado pelo wrapper.
# Imprime também as linhas de declaração, para servirem de evidência.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
INC="$ROOT/external/mgba/include"
OUT="$ROOT/logs/api_verification.log"
mkdir -p "$ROOT/logs"
[ -d "$INC" ] || { echo "ERRO: $INC não existe. Rode scripts/prepare_mgba.sh" >&2; exit 1; }

fail=0
{
  echo "mGBA commit: $(cat "$ROOT/logs/mgba_commit.txt" 2>/dev/null || echo desconhecido)"
  check() {  # $1 = regex, $2 = descrição
    local hits
    hits="$(grep -rnE "$1" "$INC" 2>/dev/null | head -3)"
    if [ -n "$hits" ]; then echo "PASS  $2"; echo "$hits" | sed 's/^/        /';
    else echo "FAIL  $2"; fail=1; fi
  }
  check 'mCoreFindVF\('                         'mCoreFindVF'
  check 'mCoreInitConfig\('                     'mCoreInitConfig'
  check 'mCoreLoadConfig\('                     'mCoreLoadConfig'
  check 'mCoreConfigSetOverrideIntValue\('      'mCoreConfigSetOverrideIntValue'
  check 'mCoreConfigSetDefaultValue\('          'mCoreConfigSetDefaultValue'
  check 'mCoreConfigDeinit\('                   'mCoreConfigDeinit'
  check 'VFileFromMemory\('                     'VFileFromMemory'
  check '\(\*init\)\('                          'mCore.init'
  check '\(\*deinit\)\('                        'mCore.deinit'
  check '\(\*loadROM\)\('                       'mCore.loadROM'
  check '\(\*reset\)\('                         'mCore.reset'
  check '\(\*runFrame\)\('                      'mCore.runFrame'
  check '\(\*setVideoBuffer\)\('                'mCore.setVideoBuffer'
  check '\(\*desiredVideoDimensions\)\('        'mCore.desiredVideoDimensions'
  check '\(\*setKeys\)\('                       'mCore.setKeys'
  check '\(\*getKeys\)\('                       'mCore.getKeys'
  check '\(\*frameCounter\)\('                  'mCore.frameCounter'
  check '\(\*busRead8\)\('                      'mCore.busRead8'
  check '\(\*busWrite8\)\('                     'mCore.busWrite8'
  check '\(\*rawRead8\)\('                      'mCore.rawRead8'
  check '\(\*getGameTitle\)\('                  'mCore.getGameTitle'
  check '\(\*getGameCode\)\('                   'mCore.getGameCode'
  check 'typedef.*color_t'                      'tipo color_t'
  echo "--- informativo: 'mColor' / image.h (esperado AUSENTE na 0.10.5)"
  grep -rnE 'mColor|mgba-util/image\.h' "$INC" 2>/dev/null | head -3 || true
  [ -f "$INC/mgba-util/image.h" ] && echo "AVISO: image.h existe" || echo "ok: image.h ausente"
  echo "--- COLOR_16_BIT definido por padrão?"
  grep -rnE 'COLOR_16_BIT' "$INC" 2>/dev/null | head -3 || true
  echo "RESULTADO: $([ $fail -eq 0 ] && echo APROVADO || echo REPROVADO)"
} 2>&1 | tee "$OUT"
exit $fail
