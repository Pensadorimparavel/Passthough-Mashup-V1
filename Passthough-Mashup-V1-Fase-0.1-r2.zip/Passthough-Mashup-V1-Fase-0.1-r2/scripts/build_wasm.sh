#!/usr/bin/env bash
# Build completo com logs e verificação dos artefatos. Não declara sucesso sem checar.
set -uo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
mkdir -p logs wasm
RES="logs/build_result.txt"; : > "$RES"
say() { echo "$*" | tee -a "$RES"; }

for t in emcc emcmake cmake git; do
  command -v "$t" >/dev/null || { say "ERRO: '$t' não encontrado (ative o Emscripten SDK)."; exit 1; }
done
say "data: $(date -u +%FT%TZ)"
say "emcc: $(emcc --version 2>&1 | head -1)"
say "cmake: $(cmake --version | head -1)"

bash scripts/prepare_mgba.sh        2>&1 | tee logs/prepare.log;  [ "${PIPESTATUS[0]}" -eq 0 ] || { say "FALHA: prepare_mgba"; exit 1; }
bash scripts/verify_mgba_api.sh >/dev/null 2>&1; VRC=$?
say "verify_mgba_api: $([ $VRC -eq 0 ] && echo APROVADO || echo REPROVADO) (ver logs/api_verification.log)"
[ $VRC -eq 0 ] || { say "FALHA: API divergente; corrigir o wrapper antes de compilar."; exit 1; }

rm -f wasm/mgba_wasm.mjs wasm/mgba_wasm.wasm
emcmake cmake -S . -B build-wasm -DCMAKE_BUILD_TYPE=Release 2>&1 | tee logs/configure.log
[ "${PIPESTATUS[0]}" -eq 0 ] || { say "FALHA: configure (logs/configure.log)"; exit 1; }
cmake --build build-wasm --parallel 2>&1 | tee logs/build.log
[ "${PIPESTATUS[0]}" -eq 0 ] || { say "FALHA: build (logs/build.log)"; exit 1; }

ok=1
for f in wasm/mgba_wasm.mjs wasm/mgba_wasm.wasm; do
  if [ -s "$f" ]; then say "artefato OK: $f ($(stat -c %s "$f") bytes)"; else say "artefato AUSENTE/VAZIO: $f"; ok=0; fi
done
if [ -s wasm/mgba_wasm.wasm ] && [ "$(head -c4 wasm/mgba_wasm.wasm | od -An -tx1 | tr -d ' \n')" != "0061736d" ]; then
  say "wasm sem magic number \\0asm"; ok=0
fi
[ $ok -eq 1 ] && say "BUILD VERIFICADO (artefatos existem). Isto NÃO prova execução." || { say "BUILD FALHOU"; exit 1; }
sha256sum wasm/mgba_wasm.mjs wasm/mgba_wasm.wasm | tee -a "$RES"
