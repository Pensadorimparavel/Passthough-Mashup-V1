// Worker de emulação (Fase 0.1). Um módulo mGBA-WASM por Worker.
import createMGBA from "../../wasm/mgba_wasm.mjs";

const PROTOCOL_VERSION = 1;
let mod = null;
let handle = 0;
let ready = false;

function reply(id, ok, payload = {}, transfer = []) {
  self.postMessage({ id, ok, ...payload }, transfer);
}
function heap() {
  const h = mod && mod.HEAPU8;
  if (!h) throw new Error("HEAPU8 não exportado pelo módulo (verifique -sEXPORTED_RUNTIME_METHODS).");
  return h; // sempre reler: a memória pode crescer e trocar o buffer
}
function requireReady() {
  if (!ready) throw new Error("Worker não inicializado.");
}
function cstr(bytes) {
  const end = bytes.indexOf(0);
  return new TextDecoder("ascii").decode(end >= 0 ? bytes.subarray(0, end) : bytes);
}
function percentile(sorted, p) {
  return sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * p))];
}

self.onmessage = async (event) => {
  const { id, type, ...m } = event.data || {};
  try {
    if (type === "init") {
      if (!ready) {
        mod = await createMGBA();
        heap(); // falha cedo se HEAPU8 não existir
        handle = mod._mgba_create() >>> 0;
        if (!handle) throw new Error("mgba_create() falhou.");
        ready = true;
      }
      reply(id, true, { protocolVersion: PROTOCOL_VERSION, memoryBytes: heap().buffer.byteLength });
      return;
    }
    requireReady();

    switch (type) {
      case "loadRom": {
        const bytes = new Uint8Array(m.rom);
        const ptr = mod._malloc(bytes.byteLength) >>> 0;
        if (!ptr) throw new Error("malloc falhou para a ROM.");
        let ok;
        try {
          heap().set(bytes, ptr);
          ok = mod._mgba_load_rom(handle, ptr, bytes.byteLength);
        } finally {
          mod._free(ptr);
        }
        if (!ok) {
          reply(id, false, { error: "load_rom recusado", errorCode: mod._mgba_get_last_error(handle) });
          return;
        }
        reply(id, true, { romBytes: bytes.byteLength, memoryBytes: heap().buffer.byteLength });
        return;
      }
      case "gameInfo": {
        const buf = mod._malloc(64) >>> 0;
        try {
          if (!mod._mgba_get_game_info(handle, buf, 32, buf + 32, 32)) throw new Error("gameInfo requer ROM carregada.");
          const h = heap();
          reply(id, true, { title: cstr(h.slice(buf, buf + 32)), code: cstr(h.slice(buf + 32, buf + 64)) });
        } finally { mod._free(buf); }
        return;
      }
      case "runFrame": {
        const before = mod._mgba_get_frame_counter(handle) | 0;
        const t0 = performance.now();
        if (!mod._mgba_run_frame(handle)) throw new Error("runFrame requer ROM carregada.");
        const durationMs = performance.now() - t0;
        reply(id, true, { before, after: mod._mgba_get_frame_counter(handle) | 0, durationMs });
        return;
      }
      case "runFrames": {
        const count = Math.max(1, Math.min(100000, Number(m.count) || 1));
        const times = new Float64Array(count);
        const wall0 = performance.now();
        for (let i = 0; i < count; i++) {
          const t0 = performance.now();
          if (!mod._mgba_run_frame(handle)) throw new Error("runFrames requer ROM carregada.");
          times[i] = performance.now() - t0;
        }
        const wallMs = performance.now() - wall0;
        const sorted = Float64Array.from(times).sort();
        reply(id, true, {
          count, wallMs,
          avgMs: wallMs / count, p95Ms: percentile(sorted, 0.95), maxMs: sorted[count - 1],
          frameCounter: mod._mgba_get_frame_counter(handle) | 0,
          memoryBytes: heap().buffer.byteLength
        });
        return;
      }
      case "setKeys": mod._mgba_set_keys(handle, Number(m.keys) >>> 0); reply(id, true); return;
      case "getKeys": reply(id, true, { keys: mod._mgba_get_keys(handle) >>> 0 }); return;
      case "readMemory8": reply(id, true, { value: mod._mgba_read_memory8(handle, Number(m.address) >>> 0) }); return;
      case "rawRead8": reply(id, true, { value: mod._mgba_raw_read8(handle, Number(m.address) >>> 0) }); return;
      case "writeMemory8":
        if (!mod._mgba_write_memory8(handle, Number(m.address) >>> 0, Number(m.value) & 0xff)) throw new Error("writeMemory8 falhou.");
        reply(id, true); return;
      case "framebuffer": {
        const ptr = mod._mgba_get_framebuffer_ptr(handle) >>> 0;
        const size = mod._mgba_get_framebuffer_size(handle) >>> 0;
        const width = mod._mgba_get_framebuffer_width(handle) >>> 0;
        const height = mod._mgba_get_framebuffer_height(handle) >>> 0;
        const bpp = mod._mgba_get_bytes_per_pixel() >>> 0;
        if (!ptr || !size) throw new Error("framebuffer indisponível.");
        if (ptr % 4) throw new Error("framebuffer desalinhado.");
        const px = new Uint32Array(heap().buffer, ptr, size >>> 2);
        let nonZero = 0; const colors = new Set();
        for (let i = 0; i < px.length; i++) {
          const c = px[i] & 0x00ffffff;
          if (c) nonZero++;
          if (colors.size < 4096) colors.add(c);
        }
        const payload = { width, height, bpp, byteLength: size, nonZeroPixels: nonZero, distinctColors: colors.size };
        if (m.withPixels) {
          const copy = heap().slice(ptr, ptr + size);
          reply(id, true, { ...payload, pixels: copy.buffer }, [copy.buffer]);
        } else reply(id, true, payload);
        return;
      }
      case "stats":
        reply(id, true, { memoryBytes: heap().buffer.byteLength, frameCounter: mod._mgba_get_frame_counter(handle) | 0 });
        return;
      case "destroy":
        mod._mgba_destroy(handle); handle = 0; ready = false; mod = null;
        reply(id, true); self.close(); return;
      default:
        throw new Error(`Comando desconhecido: ${String(type)}`);
    }
  } catch (e) {
    reply(id, false, { error: e instanceof Error ? e.message : String(e) });
  }
};
