/*
 * Wrapper mGBA 0.10.5 -> WebAssembly (Fase 0.1).
 *
 * Sequência baseada em código oficial do mGBA:
 *  - src/platform/example/client-server/server.c  (init, setVideoBuffer, config,
 *    reset, setKeys, runFrame, mCoreConfigDeinit, deinit)
 *  - src/platform/qt/CoreManager.cpp (mCoreFindVF, mCoreInitConfig,
 *    mCoreConfigSetOverrideIntValue, loadROM; quem chama fecha o VFile se
 *    mCoreFindVF falhar).
 *
 * Os símbolos usados são checados contra os headers reais por
 * scripts/verify_mgba_api.sh ANTES do build. Nada aqui foi compilado ainda.
 *
 * Propriedade de memória: em caso de sucesso o core é dono do VFile; ele é
 * liberado por core->deinit(). rom_copy precisa viver até depois do deinit.
 */
#include "mgba_wrapper.h"

#include <stdlib.h>
#include <string.h>

#include <mgba/core/core.h>
#include <mgba/core/config.h>
#include <mgba-util/vfs.h>

#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#define MGBA_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define MGBA_EXPORT
#endif

/* Se o mGBA estiver em modo COLOR_16_BIT, o formato muda: falhar alto. */
_Static_assert(sizeof(color_t) == 4, "esperado color_t de 32 bits (0.10.x sem COLOR_16_BIT)");

struct MGBAInstance {
    struct mCore* core;
    uint8_t* rom_copy;
    color_t* framebuffer;
    size_t framebuffer_bytes;
    unsigned width;
    unsigned height;
    int rom_loaded;
    int last_error;
};

static void mgba_release_core(MGBAInstance* instance) {
    if (instance->core) {
        mCoreConfigDeinit(&instance->core->config);
        instance->core->deinit(instance->core); /* libera o mCore e o VFile da ROM */
        instance->core = NULL;
    }
    free(instance->framebuffer);
    instance->framebuffer = NULL;
    instance->framebuffer_bytes = 0;
    free(instance->rom_copy);
    instance->rom_copy = NULL;
    instance->rom_loaded = 0;
}

MGBA_EXPORT MGBAInstance* mgba_create(void) {
    return (MGBAInstance*) calloc(1, sizeof(MGBAInstance));
}

MGBA_EXPORT int mgba_get_last_error(MGBAInstance* instance) {
    return instance ? instance->last_error : MGBA_ERR_BAD_ARGS;
}

MGBA_EXPORT int mgba_load_rom(MGBAInstance* instance, const uint8_t* data, size_t size) {
    if (!instance) return 0;
    instance->last_error = MGBA_ERR_NONE;
    if (!data || size < 0xC0) {
        instance->last_error = MGBA_ERR_BAD_ARGS;
        return 0;
    }

    mgba_release_core(instance); /* recarregar = recriar o core */

    instance->rom_copy = (uint8_t*) malloc(size);
    if (!instance->rom_copy) {
        instance->last_error = MGBA_ERR_NO_MEMORY;
        return 0;
    }
    memcpy(instance->rom_copy, data, size);

    struct VFile* vf = VFileFromMemory(instance->rom_copy, size);
    if (!vf) {
        free(instance->rom_copy);
        instance->rom_copy = NULL;
        instance->last_error = MGBA_ERR_VFILE;
        return 0;
    }

    struct mCore* core = mCoreFindVF(vf);
    if (!core) {
        vf->close(vf); /* padrão do Qt: o chamador fecha se FindVF falhar */
        free(instance->rom_copy);
        instance->rom_copy = NULL;
        instance->last_error = MGBA_ERR_UNRECOGNIZED_ROM;
        return 0;
    }

    if (!core->init(core)) {
        /* Contrato de limpeza após init falho não verificado: não chamar deinit. */
        vf->close(vf);
        free(instance->rom_copy);
        instance->rom_copy = NULL;
        instance->last_error = MGBA_ERR_CORE_INIT;
        return 0;
    }
    instance->core = core;

    mCoreInitConfig(core, NULL);
    /* HLE BIOS, pulando a animação de boot (sem BIOS externa). */
    mCoreConfigSetOverrideIntValue(&core->config, "useBios", 0);
    mCoreConfigSetOverrideIntValue(&core->config, "skipBios", 1);
    mCoreConfigSetDefaultValue(&core->config, "idleOptimization", "detect");

    unsigned w = 0, h = 0;
    core->desiredVideoDimensions(core, &w, &h);
    if (!w || !h) {
        mgba_release_core(instance); /* vf é fechado pelo deinit apenas se loadROM já ocorreu */
        instance->last_error = MGBA_ERR_CORE_INIT;
        return 0;
    }
    instance->width = w;
    instance->height = h;
    instance->framebuffer_bytes = (size_t) w * h * sizeof(color_t);
    instance->framebuffer = (color_t*) calloc((size_t) w * h, sizeof(color_t));
    if (!instance->framebuffer) {
        mgba_release_core(instance);
        instance->last_error = MGBA_ERR_NO_MEMORY;
        return 0;
    }
    /* stride em PIXELS, igual ao server.c oficial */
    core->setVideoBuffer(core, instance->framebuffer, w);

    if (!core->loadROM(core, vf)) {
        /* Propriedade do vf após falha de loadROM não verificada: não fechar (evita double free). */
        mgba_release_core(instance);
        instance->last_error = MGBA_ERR_LOAD_ROM;
        return 0;
    }
    mCoreLoadConfig(core);
    core->reset(core);
    instance->rom_loaded = 1;
    return 1;
}

MGBA_EXPORT int mgba_run_frame(MGBAInstance* instance) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    instance->core->runFrame(instance->core);
    return 1;
}

MGBA_EXPORT void mgba_set_keys(MGBAInstance* instance, uint32_t keys) {
    if (!instance || !instance->core || !instance->rom_loaded) return;
    instance->core->setKeys(instance->core, keys);
}

MGBA_EXPORT uint32_t mgba_get_keys(MGBAInstance* instance) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    return instance->core->getKeys(instance->core);
}

MGBA_EXPORT uint32_t mgba_read_memory8(MGBAInstance* instance, uint32_t address) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    return instance->core->busRead8(instance->core, address) & 0xFFu;
}

/* Leitura sem efeitos colaterais de barramento (para o futuro State Reader). */
MGBA_EXPORT uint32_t mgba_raw_read8(MGBAInstance* instance, uint32_t address) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    return instance->core->rawRead8(instance->core, address, -1) & 0xFFu;
}

MGBA_EXPORT int mgba_write_memory8(MGBAInstance* instance, uint32_t address, uint8_t value) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    instance->core->busWrite8(instance->core, address, value);
    return 1;
}

MGBA_EXPORT uint32_t mgba_get_frame_counter(MGBAInstance* instance) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    return (uint32_t) instance->core->frameCounter(instance->core);
}

MGBA_EXPORT int mgba_get_game_info(MGBAInstance* instance,
                                   char* title_out, size_t title_cap,
                                   char* code_out, size_t code_cap) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    if (!title_out || !code_out || !title_cap || !code_cap) return 0;
    char title[64];
    char code[64];
    memset(title, 0, sizeof(title));
    memset(code, 0, sizeof(code));
    instance->core->getGameTitle(instance->core, title);
    instance->core->getGameCode(instance->core, code);
    title[sizeof(title) - 1] = '\0';
    code[sizeof(code) - 1] = '\0';
    strncpy(title_out, title, title_cap - 1);
    title_out[title_cap - 1] = '\0';
    strncpy(code_out, code, code_cap - 1);
    code_out[code_cap - 1] = '\0';
    return 1;
}

MGBA_EXPORT uint32_t mgba_get_framebuffer_ptr(MGBAInstance* instance) {
    return (instance && instance->framebuffer) ? (uint32_t) (uintptr_t) instance->framebuffer : 0;
}
MGBA_EXPORT uint32_t mgba_get_framebuffer_size(MGBAInstance* instance) {
    return instance ? (uint32_t) instance->framebuffer_bytes : 0;
}
MGBA_EXPORT uint32_t mgba_get_framebuffer_width(MGBAInstance* instance) {
    return instance ? instance->width : 0;
}
MGBA_EXPORT uint32_t mgba_get_framebuffer_height(MGBAInstance* instance) {
    return instance ? instance->height : 0;
}
MGBA_EXPORT uint32_t mgba_get_bytes_per_pixel(void) {
    return (uint32_t) sizeof(color_t);
}

MGBA_EXPORT void mgba_destroy(MGBAInstance* instance) {
    if (!instance) return;
    mgba_release_core(instance);
    free(instance);
}
