#ifndef PASSTHOUGH_MGBA_WRAPPER_H
#define PASSTHOUGH_MGBA_WRAPPER_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Códigos de erro (mgba_get_last_error). 0 = sem erro. */
enum {
    MGBA_ERR_NONE = 0,
    MGBA_ERR_BAD_ARGS = 1,
    MGBA_ERR_NO_MEMORY = 2,
    MGBA_ERR_VFILE = 3,
    MGBA_ERR_UNRECOGNIZED_ROM = 4, /* mCoreFindVF() não reconheceu a ROM */
    MGBA_ERR_CORE_INIT = 5,
    MGBA_ERR_LOAD_ROM = 6
};

typedef struct MGBAInstance MGBAInstance;

MGBAInstance* mgba_create(void);
int mgba_load_rom(MGBAInstance* instance, const uint8_t* data, size_t size);
int mgba_get_last_error(MGBAInstance* instance);
int mgba_run_frame(MGBAInstance* instance);
void mgba_set_keys(MGBAInstance* instance, uint32_t keys);
uint32_t mgba_get_keys(MGBAInstance* instance);
uint32_t mgba_read_memory8(MGBAInstance* instance, uint32_t address);
uint32_t mgba_raw_read8(MGBAInstance* instance, uint32_t address);
int mgba_write_memory8(MGBAInstance* instance, uint32_t address, uint8_t value);
uint32_t mgba_get_frame_counter(MGBAInstance* instance);
int mgba_get_game_info(MGBAInstance* instance,
                       char* title_out, size_t title_cap,
                       char* code_out, size_t code_cap);
uint32_t mgba_get_framebuffer_ptr(MGBAInstance* instance);
uint32_t mgba_get_framebuffer_size(MGBAInstance* instance);
uint32_t mgba_get_framebuffer_width(MGBAInstance* instance);
uint32_t mgba_get_framebuffer_height(MGBAInstance* instance);
uint32_t mgba_get_bytes_per_pixel(void);
void mgba_destroy(MGBAInstance* instance);

#ifdef __cplusplus
}
#endif

#endif
