# Passthough Mashup V1 — Fase 0.1 (revisão 2)

Base: **mGBA 0.10.5** (tag oficial), compilado com Emscripten como módulo ES (`.mjs` + `.wasm`),
um módulo por Dedicated Worker. Sem pthreads, sem SharedArrayBuffer, sem EmulatorJS.

## Estado verificado (honesto)
| Item | Estado |
|---|---|
| Análise estática (bash -n, node --check) | feita, passou |
| Sintaxe do wrapper C contra **stubs próprios** | passou — NÃO prova a API real |
| Símbolos do wrapper nos headers reais da 0.10.5 | **NÃO verificado** — rode `scripts/verify_mgba_api.sh` |
| Compilação Emscripten | **NÃO executada** (sandbox sem rede/emcc) |
| Execução real / desempenho / Android | **NÃO executados** |

## Como compilar (máquina com emsdk ativado)
```bash
bash scripts/build_wasm.sh
```
O script: clona a tag 0.10.5, roda `verify_mgba_api.sh` (aborta se divergir), configura, compila e
só afirma "BUILD VERIFICADO" se `wasm/mgba_wasm.mjs` e `.wasm` existirem (magic `\0asm`).
Logs em `logs/`: `api_verification.log`, `configure.log`, `build.log`, `build_result.txt`.

## Compilar pelo GitHub Actions (sem instalar nada)
1. Crie um repositório no GitHub e envie o conteúdo desta pasta (incluindo `.github/`).
2. Aba **Actions** → workflow **Build mGBA WASM (Fase 0.1)** → **Run workflow**
   (a versão do Emscripten é um campo; padrão `3.1.74`, não validada por mim — se for inválida o passo de instalação falha com mensagem clara).
3. Ao terminar, abra a execução:
   - **Artifacts → `logs-fase-0-1`**: sempre enviado, inclusive em falha (verificação de API, configure, build, versões).
   - **Artifacts → `mgba-wasm-0.10.5`**: só existe se tudo passou; contém `mgba_wasm.mjs` e `mgba_wasm.wasm`.
   - A página de resumo mostra versão do emcc, commit do mGBA e resultado.
4. Em caso de falha, envie os logs para correção. Em caso de sucesso, coloque os dois arquivos em `wasm/`
   e abra `tests/phase0_1.html` (veja "Testar").

Compilar com sucesso **não** aprova a Fase 0.1: faltam os testes A–G no navegador, o teste sustentado e a validação no Android.

## Testar
```bash
python3 -m http.server 8000   # abrir /tests/phase0_1.html
```
Critérios A–G e P estão descritos no topo de `tests/phase0_1.js`. O botão "Teste sustentado" roda os
dois workers por N minutos e registra ms/frame a cada 30 s (tendência de alta = estrangulamento).
Para Android, servir pela rede local (http://IP:8000) e usar "Baixar log".

## Mudanças desta revisão
- Wrapper reescrito no fluxo oficial (`mCoreFindVF` → `init` → `mCoreInitConfig` → overrides →
  `desiredVideoDimensions` → `setVideoBuffer` → `loadROM` → `mCoreLoadConfig` → `reset`).
- `color_t` (0.10.x) no lugar de `mColor`/`image.h`; `_Static_assert` de 32 bits.
- Validação real de ROM (`mCoreFindVF`), códigos de erro, título/código do jogo, `rawRead8`.
- CMake: `flags.h` gerado localizado automaticamente; saída direta em `wasm/`; sem patch no upstream.
- Testes reescritos sem asserts vazios; contadores independentes (G); aquecimento; p95; sustentado.

## Pendências conhecidas
- Logger do core (`mLogger`) não integrado; áudio não configurado (efeito de não drenar: desconhecido).
- Propriedade do `VFile` após falha de `loadROM`/`init` não verificada (o wrapper evita double free, podendo vazar).
- Opções CMake além das confirmadas são tentativas defensivas; ver `logs/configure.log`.
- Formato dos pixels (0x00BBGGRR, alfa=0) a confirmar no teste E antes de converter para Canvas.

Licença: wrapper experimental próprio; mGBA é MPL-2.0 (preserve os avisos do upstream).
