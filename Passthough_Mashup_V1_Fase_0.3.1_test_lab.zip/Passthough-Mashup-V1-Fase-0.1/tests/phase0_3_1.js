/**
 * Passthough Mashup V1 — Fase 0.3.1
 * Interactive single-ROM browser test lab.
 * Uses the existing emulator Worker API; does not modify the core or old tests.
 */
import { MemoryReader } from "../src/state/memory/MemoryReader.js";
import { ZeldaStateAdapter } from "../src/state/adapters/ZeldaStateAdapter.js";
import { BuuFuryStateAdapter } from "../src/state/adapters/BuuFuryStateAdapter.js";

const $ = (selector) => document.querySelector(selector);
const ui = {
  romFile: $("#romFile"), profile: $("#gameProfile"), load: $("#loadGame"),
  pause: $("#pauseGame"), stop: $("#stopGame"), canvas: $("#gameScreen"),
  gameStatus: $("#gameStatus"), frameStatus: $("#frameStatus"),
  readStates: $("#readStates"), stateStatus: $("#stateStatus"), stateRaw: $("#stateRaw"),
  log: $("#log"), x: $("#stateX"), y: $("#stateY"), direction: $("#stateDirection"),
  movement: $("#stateMovement"), animation: $("#stateAnimation"), hp: $("#stateHp"),
  character: $("#stateCharacter"), speed: $("#stateSpeed")
};

const ctx = ui.canvas.getContext("2d", { alpha: false });
const imageData = ctx.createImageData(240, 160);
const KEY_MASK = Object.freeze({
  a: 1 << 0, b: 1 << 1, select: 1 << 2, start: 1 << 3,
  right: 1 << 4, left: 1 << 5, up: 1 << 6, down: 1 << 7,
  r: 1 << 8, l: 1 << 9
});
const pressed = new Set();
const keyToButton = new Map([
  ["ArrowUp", "up"], ["ArrowDown", "down"], ["ArrowLeft", "left"], ["ArrowRight", "right"],
  ["KeyX", "a"], ["KeyZ", "b"], ["KeyA", "l"], ["KeyS", "r"],
  ["Enter", "start"], ["ShiftRight", "select"]
]);

let worker = null;
let workerRequestId = 0;
let pending = new Map();
let memoryReader = null;
let stateAdapter = null;
let running = false;
let busy = false;
let destroyed = false;
let frameNumber = 0;
let lastStateRead = 0;
let stateReadBusy = false;
let animationHandle = 0;
let stateTimer = 0;
let currentKeys = 0;

function log(message, kind = "") {
  const line = document.createElement("div");
  if (kind) line.className = kind;
  line.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
  ui.log.appendChild(line);
  ui.log.scrollTop = ui.log.scrollHeight;
}

function setStatus(message, kind = "") {
  ui.gameStatus.textContent = message;
  ui.gameStatus.className = kind;
}

function createWorker() {
  const raw = new Worker(new URL("../src/workers/emulator.worker.js", import.meta.url), { type: "module" });
  pending = new Map();
  raw.onmessage = (event) => {
    const message = event.data || {};
    if (message.type === "bridgeOut" || message.type === "bridgeResponse") return;
    const entry = pending.get(message.id);
    if (!entry) return;
    pending.delete(message.id);
    clearTimeout(entry.timeout);
    if (message.ok) entry.resolve(message);
    else entry.reject(new Error(message.error || "Erro não especificado no Worker."));
  };
  raw.onerror = (event) => {
    const error = new Error(event.message || "Falha no Worker do emulador.");
    for (const entry of pending.values()) {
      clearTimeout(entry.timeout);
      entry.reject(error);
    }
    pending.clear();
    setStatus("Erro no Worker.", "error");
    log(error.message, "error");
  };
  return {
    raw,
    request(type, payload = {}, transfer = []) {
      if (destroyed) return Promise.reject(new Error("A sessão do Worker foi encerrada."));
      const id = ++workerRequestId;
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          pending.delete(id);
          reject(new Error(`Timeout aguardando resposta do Worker: ${type}`));
        }, 10000);
        pending.set(id, { resolve, reject, timeout });
        raw.postMessage({ id, type, ...payload }, transfer);
      });
    },
    terminate() {
      destroyed = true;
      raw.terminate();
      for (const entry of pending.values()) {
        clearTimeout(entry.timeout);
        entry.reject(new Error("Worker encerrado."));
      }
      pending.clear();
    }
  };
}

function renderFramebuffer(frame) {
  if (!(frame.pixels instanceof ArrayBuffer) || frame.width !== 240 || frame.height !== 160) {
    throw new Error("Framebuffer inválido: formato ou dimensões inesperadas.");
  }
  const source = new Uint8Array(frame.pixels);
  if (source.length < imageData.data.length) throw new Error("Framebuffer menor que o esperado.");
  // The current WASM build returns mColor XBGR8. On the little-endian GBA/WASM
  // build used here, bytes are R,G,B,X; force opaque alpha for Canvas ImageData.
  for (let src = 0, dst = 0; dst < imageData.data.length; src += 4, dst += 4) {
    imageData.data[dst] = source[src];
    imageData.data[dst + 1] = source[src + 1];
    imageData.data[dst + 2] = source[src + 2];
    imageData.data[dst + 3] = 255;
  }
  ctx.putImageData(imageData, 0, 0);
}

function setPressed(button, isDown) {
  if (!KEY_MASK[button] || !worker) return;
  if (isDown) pressed.add(button);
  else pressed.delete(button);
  let mask = 0;
  for (const key of pressed) mask |= KEY_MASK[key];
  if (mask === currentKeys) return;
  currentKeys = mask;
  worker.request("setKeys", { keys: currentKeys }).catch((error) => log(`Falha ao enviar controle: ${error.message}`, "error"));
}

function releaseAllKeys() {
  pressed.clear();
  currentKeys = 0;
  if (worker) worker.request("setKeys", { keys: 0 }).catch(() => {});
}

function attachControls() {
  document.querySelectorAll("[data-key]").forEach((button) => {
    const key = button.dataset.key;
    button.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      button.setPointerCapture?.(event.pointerId);
      setPressed(key, true);
    });
    const release = (event) => { event.preventDefault(); setPressed(key, false); };
    button.addEventListener("pointerup", release);
    button.addEventListener("pointercancel", release);
    button.addEventListener("lostpointercapture", () => setPressed(key, false));
    button.addEventListener("contextmenu", (event) => event.preventDefault());
  });
  window.addEventListener("keydown", (event) => {
    const key = keyToButton.get(event.code);
    if (!key) return;
    event.preventDefault();
    if (!event.repeat) setPressed(key, true);
  });
  window.addEventListener("keyup", (event) => {
    const key = keyToButton.get(event.code);
    if (!key) return;
    event.preventDefault();
    setPressed(key, false);
  });
  window.addEventListener("blur", releaseAllKeys);
  document.addEventListener("visibilitychange", () => { if (document.hidden) releaseAllKeys(); });
}

function clearStateDisplay(message = "Aguardando sessão.") {
  for (const node of [ui.x, ui.y, ui.direction, ui.movement, ui.animation, ui.hp, ui.character, ui.speed]) node.textContent = "—";
  ui.stateStatus.textContent = message;
  ui.stateRaw.textContent = "Nenhum estado lido.";
}

function showState(state) {
  ui.x.textContent = state.position?.x ?? "—";
  ui.y.textContent = state.position?.y ?? "—";
  ui.direction.textContent = state.direction ?? "—";
  ui.movement.textContent = state.movementState ?? "—";
  ui.animation.textContent = state.animationState ?? "—";
  ui.hp.textContent = state.hp == null ? "—" : `${state.hp}/${state.maxHp ?? "?"}`;
  ui.character.textContent = state.currentCharacter ?? "—";
  ui.speed.textContent = state.speed ?? "—";
  ui.stateStatus.textContent = `Atualizado às ${new Date(state.timestamp).toLocaleTimeString()} · ${state.game}`;
  ui.stateRaw.textContent = JSON.stringify({
    game: state.game, raw: state.raw, confidence: state.confidence, notes: state.notes
  }, null, 2);
}

async function readCurrentState() {
  if (stateReadBusy) return;
  if (!memoryReader || !stateAdapter) {
    ui.stateStatus.textContent = "Perfil genérico: ainda não há adaptador específico para este jogo.";
    return;
  }
  if (Date.now() - lastStateRead < 100) return;
  lastStateRead = Date.now();
  stateReadBusy = true;
  try {
    const state = await stateAdapter.readState();
    showState(state);
  } catch (error) {
    ui.stateStatus.textContent = `Falha na leitura: ${error.message}`;
    log(`Falha ao extrair estado: ${error.message}`, "error");
  } finally {
    stateReadBusy = false;
  }
}

async function animationStep() {
  if (!running || busy || !worker) return;
  busy = true;
  try {
    const frame = await worker.request("runFrame");
    const fb = await worker.request("framebuffer");
    renderFramebuffer(fb);
    frameNumber = frame.frameCounter;
    ui.frameStatus.textContent = `Frames: ${frameNumber}`;
    // State reads run independently so they do not hold the frame loop.
    if (stateAdapter && Date.now() - lastStateRead > 500) void readCurrentState();
  } catch (error) {
    running = false;
    cancelAnimationFrame(animationHandle);
    setStatus(`Emulação interrompida: ${error.message}`, "error");
    log(error.message, "error");
    ui.pause.disabled = true;
  } finally {
    busy = false;
  }
  if (running) animationHandle = requestAnimationFrame(animationStep);
}

function startLoop() {
  if (running || !worker) return;
  running = true;
  ui.pause.textContent = "Pausar";
  ui.pause.disabled = false;
  animationHandle = requestAnimationFrame(animationStep);
}

function stopLoop() {
  running = false;
  cancelAnimationFrame(animationHandle);
  releaseAllKeys();
}

function stopSession() {
  stopLoop();
  if (stateTimer) clearInterval(stateTimer);
  stateTimer = 0;
  if (worker) worker.terminate();
  worker = null;
  memoryReader = null;
  stateAdapter = null;
  ui.load.disabled = false;
  ui.pause.disabled = true;
  ui.stop.disabled = true;
  ui.readStates.disabled = true;
  ui.pause.textContent = "Pausar";
  ui.frameStatus.textContent = "Frames: —";
  setStatus("Sessão encerrada.");
  clearStateDisplay("Aguardando sessão.");
  log("Sessão encerrada.");
}

ui.load.addEventListener("click", async () => {
  const file = ui.romFile.files?.[0];
  if (!file) {
    setStatus("Selecione um arquivo de ROM GBA.", "warn");
    log("Nenhuma ROM selecionada.", "warn");
    return;
  }
  if (worker) stopSession();
  ui.load.disabled = true;
  setStatus("Inicializando mGBA…");
  ui.log.textContent = "";
  frameNumber = 0;
  stateReadBusy = false;
  lastStateRead = 0;
  try {
    const romBuffer = await file.arrayBuffer();
    if (romBuffer.byteLength < 0xc0) throw new Error("Arquivo muito pequeno para ser uma ROM GBA válida.");
    destroyed = false;
    workerRequestId = 0;
    worker = createWorker();
    const ready = await worker.request("init");
    log(`Worker inicializado · WASM: ${ready.memoryBytes.toLocaleString()} bytes.`);
    const loaded = await worker.request("loadRom", { rom: romBuffer }, [romBuffer]);
    log(`ROM carregada · ${loaded.romBytes.toLocaleString()} bytes.`);

    memoryReader = new MemoryReader(worker);
    await memoryReader.enableReadOnlyPolicy();
    const policy = await memoryReader.getWritePolicyState();
    if (policy.memoryWriteEnabled || !policy.memoryWriteLocked) throw new Error("Worker não confirmou a política read-only.");
    log("Trava irreversível de escrita confirmada nesta sessão.", "ok");

    const profile = ui.profile.value;
    if (profile === "zelda") stateAdapter = new ZeldaStateAdapter(memoryReader);
    else if (profile === "buus_fury") stateAdapter = new BuuFuryStateAdapter(memoryReader);
    else stateAdapter = null;

    ctx.clearRect(0, 0, 240, 160);
    const firstFrame = await worker.request("runFrame");
    const firstBuffer = await worker.request("framebuffer");
    renderFramebuffer(firstBuffer);
    frameNumber = firstFrame.frameCounter;
    ui.frameStatus.textContent = `Frames: ${frameNumber}`;
    ui.pause.disabled = false;
    ui.stop.disabled = false;
    ui.readStates.disabled = !stateAdapter;
    ui.load.disabled = false;
    setStatus(`Em execução: ${file.name}`, "ok");
    log("Primeiro frame renderizado com sucesso.", "ok");
    if (stateAdapter) await readCurrentState();
    else clearStateDisplay("Perfil genérico: emulação ativa, sem adaptador de estados selecionado.");
    startLoop();
  } catch (error) {
    log(`ERRO: ${error.message}`, "error");
    setStatus(`Falha ao carregar: ${error.message}`, "error");
    if (worker) worker.terminate();
    worker = null;
    memoryReader = null;
    stateAdapter = null;
    ui.load.disabled = false;
    ui.pause.disabled = true;
    ui.stop.disabled = true;
    ui.readStates.disabled = true;
  }
});

ui.pause.addEventListener("click", () => {
  if (!worker) return;
  if (running) {
    stopLoop();
    ui.pause.textContent = "Retomar";
    setStatus("Emulação pausada.", "warn");
    log("Emulação pausada.");
  } else {
    setStatus("Em execução.", "ok");
    log("Emulação retomada.");
    startLoop();
  }
});

ui.stop.addEventListener("click", stopSession);
ui.readStates.addEventListener("click", () => readCurrentState());
attachControls();
clearStateDisplay();
