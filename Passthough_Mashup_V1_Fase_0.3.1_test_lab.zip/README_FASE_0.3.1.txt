Passthough Mashup V1 — pacote de implementação Fase 0.3.1

Conteúdo:
- Passthough-Mashup-V1-Fase-0.1/tests/phase0_3_1.html
- Passthough-Mashup-V1-Fase-0.1/tests/phase0_3_1.js

Compatibilidade esperada:
- Requer a estrutura já publicada das Fases 0.1 e 0.3:
  src/workers/emulator.worker.js
  src/state/memory/MemoryReader.js
  src/state/adapters/ZeldaStateAdapter.js
  src/state/adapters/BuuFuryStateAdapter.js
  wasm/mgba_wasm.mjs e wasm/mgba_wasm.wasm
- Não altera o Worker, os adaptadores nem os testes anteriores.
- A sessão interativa ativa a trava read-only irreversível no Worker.
- O perfil do jogo é selecionado manualmente; não há identificação automática de ROM nesta fase.

URL esperada após publicação:
/tests/phase0_3_1.html

Nota técnica:
A conversão do framebuffer assume o formato XBGR8 declarado pelo wrapper mGBA e a representação little-endian usada pelo build WASM atual (bytes R,G,B,X). Isso deve ser confirmado visualmente no primeiro teste de navegador.
