/**
 * Passthough Mashup V1 — Fase 0.2.1
 * Automated tests for the Bridge using the real Workers from Phase 0.1.
 *
 * Primary proof of communication is Worker-originated:
 *   Worker.request("bridgeEmit", { envelope }) → bridgeOut → Bridge → other Worker
 * Main-thread bridge.send() is NOT used as proof of Worker↔Worker.
 */

import { Bridge } from "../src/bridge/Bridge.js";
import {
  createEnvelope,
  validateEnvelope,
  PROTOCOL_VERSION
} from "../src/bridge/MessageProtocol.js";

const logElement = document.querySelector("#log");
const runButton = document.querySelector("#runTests");
const stopButton = document.querySelector("#stopWorkers");
const romAInput = document.querySelector("#romA");
const romBInput = document.querySelector("#romB");

let workers = [];
let bridge = null;
let passed = 0;
let failed = 0;

function log(message, cls = "") {
  const line = document.createElement("div");
  if (cls) line.className = cls;
  line.textContent = message;
  logElement.appendChild(line);
  logElement.scrollTop = logElement.scrollHeight;
}

function assert(condition, message) {
  if (!condition) {
    failed += 1;
    log(`FALHOU: ${message}`, "fail");
    throw new Error(`FALHOU: ${message}`);
  }
  passed += 1;
  log(`OK: ${message}`, "ok");
}

function makeWorker() {
  const worker = new Worker(
    new URL("../src/workers/emulator.worker.js", import.meta.url),
    { type: "module" }
  );
  let nextId = 1;
  const pending = new Map();

  worker.onmessage = (event) => {
    const message = event.data;
    // Bridge channel is handled exclusively by the Bridge class.
    if (message && (message.type === "bridgeOut" || message.type === "bridgeResponse")) {
      return;
    }
    const item = pending.get(message.id);
    if (!item) return;
    pending.delete(message.id);
    if (message.ok) item.resolve(message);
    else item.reject(new Error(message.error || "Erro não especificado no worker."));
  };

  worker.onerror = (event) => {
    for (const item of pending.values()) item.reject(new Error(event.message));
    pending.clear();
  };

  return {
    raw: worker,
    request(type, payload = {}, transfer = []) {
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        worker.postMessage({ id, type, ...payload }, transfer);
      });
    },
    terminate() {
      worker.terminate();
      for (const item of pending.values()) item.reject(new Error("Worker encerrado."));
      pending.clear();
    }
  };
}

/**
 * Worker-originated send:
 * 1. Register expectResponse(messageId) on the Bridge
 * 2. Ask the source Worker to emit via bridgeEmit → bridgeOut
 * 3. Bridge forces real origin, validates, forwards to destination
 * 4. Destination replies with bridgeResponse → promise resolves
 */
async function workerEmit(bridge, sourceWorker, origin, destination, type, payload, timeoutMs = 8000) {
  const envelope = createEnvelope({ origin, destination, type, payload });
  const responsePromise = bridge.expectResponse(envelope.messageId, timeoutMs);
  await sourceWorker.request("bridgeEmit", { envelope });
  return responsePromise;
}

async function readFile(input, fallback) {
  const file = input.files?.[0] || fallback;
  if (!file) {
    throw new Error(
      "Selecione uma ROM GBA para cada worker (ou selecione apenas A para reutilizá-la em B)."
    );
  }
  return file.arrayBuffer();
}

function stopAll() {
  if (bridge) {
    bridge.destroy();
    bridge = null;
  }
  for (const w of workers) w.terminate();
  workers = [];
}

stopButton.addEventListener("click", () => {
  stopAll();
  log("\nWorkers e Bridge encerrados pelo usuário.");
});

runButton.addEventListener("click", async () => {
  runButton.disabled = true;
  stopAll();
  logElement.textContent = "";
  passed = 0;
  failed = 0;

  try {
    // ----------------------------------------------------------------
    // Bootstrap + regressão Fase 0.1
    // ----------------------------------------------------------------
    log("=== Bootstrap (regressão Fase 0.1) ===");
    const romBufferA = await readFile(romAInput);
    const romBufferB = await readFile(romBInput, romAInput.files?.[0]);

    const workerA = makeWorker();
    const workerB = makeWorker();
    workers = [workerA, workerB];

    const [readyA, readyB] = await Promise.all([
      workerA.request("init"),
      workerB.request("init")
    ]);
    assert(readyA.type === "ready", "Worker A inicializou o núcleo mGBA");
    assert(readyB.type === "ready", "Worker B inicializou o núcleo mGBA");
    assert(workerA.raw !== workerB.raw, "Dois Dedicated Workers distintos foram criados");

    await Promise.all([
      workerA.request("loadRom", { rom: romBufferA }, [romBufferA]),
      workerB.request("loadRom", { rom: romBufferB }, [romBufferB])
    ]);
    assert(true, "ROMs carregadas em A e B");

    const [frameA, frameB] = await Promise.all([
      workerA.request("runFrame"),
      workerB.request("runFrame")
    ]);
    assert(
      frameA.frameCounter === frameA.beforeFrameCounter + 1,
      "Worker A avançou exatamente um frame (regressão)"
    );
    assert(
      frameB.frameCounter === frameB.beforeFrameCounter + 1,
      "Worker B avançou exatamente um frame (regressão)"
    );

    // ----------------------------------------------------------------
    // Bridge
    // ----------------------------------------------------------------
    log("\n=== Criando Bridge ===");
    const rejects = [];
    const received = [];

    bridge = new Bridge(workerA, workerB, {
      onLog: () => {},
      onMessage: (ev) => {
        received.push(ev);
      },
      onReject: (ev) => {
        rejects.push(ev);
      }
    });
    assert(true, "Bridge instanciada na thread principal");

    // ----------------------------------------------------------------
    // T1: Worker A emite → Bridge identifica origem real A → B recebe e confirma
    // ----------------------------------------------------------------
    log("\n=== T1: Worker A emite (bridgeEmit) → B ===");
    const t1 = await workerEmit(bridge, workerA, "A", "B", "ping", { seq: 1, from: "WorkerA" });
    assert(t1.type === "pong", "T1: B respondeu com pong (confirmação de recebimento)");
    assert(t1.origin === "B", "T1: origem real da resposta é B");
    assert(t1.destination === "A", "T1: destino da resposta é A");
    assert(t1.payload && t1.payload.pong === true, "T1: payload pong correto");
    assert(
      t1.payload.echo && t1.payload.echo.seq === 1 && t1.payload.echo.from === "WorkerA",
      "T1: payload original ecoado corretamente"
    );
    assert(
      received.some((r) => r.realOrigin === "A" && r.envelope && r.envelope.type === "ping"),
      "T1: Bridge registrou origem real A no bridgeOut"
    );

    // ----------------------------------------------------------------
    // T2: Worker B emite → Bridge identifica origem real B → A recebe e confirma
    // ----------------------------------------------------------------
    log("\n=== T2: Worker B emite (bridgeEmit) → A ===");
    const t2 = await workerEmit(bridge, workerB, "B", "A", "ping", { seq: 2, from: "WorkerB" });
    assert(t2.type === "pong", "T2: A respondeu com pong (confirmação de recebimento)");
    assert(t2.origin === "A", "T2: origem real da resposta é A");
    assert(t2.destination === "B", "T2: destino da resposta é B");
    assert(
      t2.payload && t2.payload.echo && t2.payload.echo.seq === 2,
      "T2: payload original ecoado corretamente"
    );
    assert(
      received.some((r) => r.realOrigin === "B" && r.envelope && r.envelope.type === "ping"),
      "T2: Bridge registrou origem real B no bridgeOut"
    );

    // ----------------------------------------------------------------
    // T3: Comunicação simultânea originada nos dois Workers
    // ----------------------------------------------------------------
    log("\n=== T3: Simultâneo originado pelos Workers ===");
    const envA = createEnvelope({
      origin: "A",
      destination: "B",
      type: "echo",
      payload: { side: "A", n: 42 }
    });
    const envB = createEnvelope({
      origin: "B",
      destination: "A",
      type: "echo",
      payload: { side: "B", n: 99 }
    });
    const pA = bridge.expectResponse(envA.messageId, 8000);
    const pB = bridge.expectResponse(envB.messageId, 8000);
    await Promise.all([
      workerA.request("bridgeEmit", { envelope: envA }),
      workerB.request("bridgeEmit", { envelope: envB })
    ]);
    const [simA, simB] = await Promise.all([pA, pB]);
    assert(
      simA.type === "echo" && simA.payload && simA.payload.side === "A",
      "T3: A→B echo ok (Worker-originated)"
    );
    assert(
      simB.type === "echo" && simB.payload && simB.payload.side === "B",
      "T3: B→A echo ok (Worker-originated)"
    );
    assert(simA.origin === "B" && simB.origin === "A", "T3: origens das respostas corretas");

    // ----------------------------------------------------------------
    // T4: Rejeição de envelopes inválidos recebidos via bridgeOut
    // ----------------------------------------------------------------
    log("\n=== T4: Rejeição de envelopes inválidos via bridgeOut ===");
    const rejectsBefore = rejects.length;

    const badVer = {
      protocolVersion: 999,
      messageId: `badver_${Date.now()}`,
      origin: "A",
      destination: "B",
      type: "ping",
      timestamp: Date.now(),
      payload: null
    };
    await workerA.request("bridgeEmit", { envelope: badVer });
    await new Promise((r) => setTimeout(r, 50));
    assert(
      rejects.length > rejectsBefore &&
        rejects.some((r) => String(r.reason).includes("protocolVersion")),
      "T4: protocolVersion inválido rejeitado no canal bridgeOut"
    );

    const rejectsBefore2 = rejects.length;
    const badType = createEnvelope({ origin: "A", destination: "B", type: "ping", payload: null });
    badType.type = "not_allowed_type";
    await workerA.request("bridgeEmit", { envelope: badType });
    await new Promise((r) => setTimeout(r, 50));
    assert(
      rejects.length > rejectsBefore2 &&
        rejects.some(
          (r) =>
            String(r.reason).includes("disallowed type") ||
            String(r.reason).includes("not_allowed")
        ),
      "T4: type inválido rejeitado no canal bridgeOut"
    );

    const missing = validateEnvelope({ origin: "A", destination: "B" });
    assert(missing.valid === false, "T4: envelope incompleto rejeitado por validateEnvelope");

    // ----------------------------------------------------------------
    // T5: Self-destination e destino inválido são rejeitados.
    // Origin spoof NÃO é rejeitado: a Bridge substitui a origem declarada
    // pela origem real da instância e encaminha se o restante for válido.
    // Isso comprova que a Bridge não confia no campo origin informado.
    // ----------------------------------------------------------------
    log("\n=== T5: Self-destination / destino inválido (rejeição) + origin spoof (correção e encaminhamento) ===");
    const rejectsBefore3 = rejects.length;
    const selfEnv = {
      protocolVersion: PROTOCOL_VERSION,
      messageId: `self_${Date.now()}`,
      origin: "A",
      destination: "A",
      type: "ping",
      timestamp: Date.now(),
      payload: null
    };
    await workerA.request("bridgeEmit", { envelope: selfEnv });
    await new Promise((r) => setTimeout(r, 50));
    assert(
      rejects.length > rejectsBefore3 &&
        rejects.some(
          (r) =>
            String(r.reason).includes("self-destination") ||
            String(r.reason).includes("must be different")
        ),
      "T5: self-destination rejeitado no canal bridgeOut"
    );

    const rejectsBefore4 = rejects.length;
    const badDest = {
      protocolVersion: PROTOCOL_VERSION,
      messageId: `baddest_${Date.now()}`,
      origin: "A",
      destination: "C",
      type: "ping",
      timestamp: Date.now(),
      payload: null
    };
    await workerA.request("bridgeEmit", { envelope: badDest });
    await new Promise((r) => setTimeout(r, 50));
    assert(
      rejects.length > rejectsBefore4 &&
        rejects.some((r) => String(r.reason).includes("Invalid destination")),
      "T5: destination inexistente rejeitado no canal bridgeOut"
    );

    // Worker A claims origin "B". Bridge does NOT reject the spoof:
    // it replaces origin with the real instance (A) and forwards if valid.
    const spoofOk = createEnvelope({
      origin: "B",
      destination: "B",
      type: "test",
      payload: { claimed: "B" }
    });
    // After force origin=A, destination must be B for a valid A→B
    spoofOk.destination = "B";
    const spoofMsgId = spoofOk.messageId;
    const spoofPromise = bridge.expectResponse(spoofMsgId, 8000);
    await workerA.request("bridgeEmit", { envelope: spoofOk });
    const spoofResp = await spoofPromise;
    assert(
      spoofResp.type === "ack",
      "T5: origin spoof corrigido (não rejeitado) e mensagem encaminhada com sucesso"
    );
    assert(
      received.some(
        (r) =>
          r.realOrigin === "A" &&
          r.envelope &&
          r.envelope.messageId === spoofMsgId &&
          r.envelope.origin === "A"
      ),
      "T5: Bridge substituiu origin declarado B pela origem real A e encaminhou"
    );

    // ----------------------------------------------------------------
    // T5b: Resposta do Worker errado e correlationId divergente
    // Ambos devem ser rejeitados SEM resolver a promessa pendente.
    // Pending is registered with routing but without a real deliver, so
    // only the forged response is observed.
    // ----------------------------------------------------------------
    log("\n=== T5b: Worker errado / correlationId divergente (não resolvem pending) ===");

    // --- Wrong responder: pending expects B, Worker A forges the response ---
    const wrongMsgId = `wrong_${Date.now()}_AtoB`;
    const wrongPromise = bridge.expectResponse(wrongMsgId, 1500, {
      expectedResponder: "B",
      expectedReplyTo: "A"
    });

    const rejectsBeforeWrong = rejects.length;
    await workerA.request("bridgeForgeResponse", {
      inReplyTo: wrongMsgId,
      envelope: {
        protocolVersion: PROTOCOL_VERSION,
        messageId: `forge_${Date.now()}`,
        origin: "A",
        destination: "A",
        type: "pong",
        timestamp: Date.now(),
        payload: { forged: true },
        correlationId: wrongMsgId
      }
    });
    await new Promise((r) => setTimeout(r, 50));

    assert(
      rejects.length > rejectsBeforeWrong &&
        rejects.some((r) => String(r.reason).includes("wrong Worker")),
      "T5b: resposta do Worker errado rejeitada"
    );

    let wrongResolved = false;
    let wrongRejected = false;
    wrongPromise.then(() => {
      wrongResolved = true;
    }).catch(() => {
      wrongRejected = true;
    });
    await new Promise((r) => setTimeout(r, 80));
    assert(wrongResolved === false, "T5b: promessa NÃO resolvida pelo Worker errado");
    // Allow timeout to settle
    try {
      await wrongPromise;
    } catch (_) {
      wrongRejected = true;
    }
    assert(wrongRejected === true, "T5b: promessa do Worker errado terminou em rejeição/timeout, não em resolve");

    // --- Divergent correlationId: inReplyTo != envelope.correlationId ---
    const divMsgId = `div_${Date.now()}_AtoB`;
    const divPromise = bridge.expectResponse(divMsgId, 1500, {
      expectedResponder: "B",
      expectedReplyTo: "A"
    });

    const rejectsBeforeDiv = rejects.length;
    // Correct Worker (B) but correlationId does not match inReplyTo / original id
    await workerB.request("bridgeForgeResponse", {
      inReplyTo: divMsgId,
      envelope: {
        protocolVersion: PROTOCOL_VERSION,
        messageId: `div_${Date.now()}`,
        origin: "B",
        destination: "A",
        type: "pong",
        timestamp: Date.now(),
        payload: { forged: true },
        correlationId: "completely-different-id"
      }
    });
    await new Promise((r) => setTimeout(r, 50));

    assert(
      rejects.length > rejectsBeforeDiv &&
        rejects.some(
          (r) =>
            String(r.reason).includes("diverge") ||
            String(r.reason).includes("does not match original")
        ),
      "T5b: correlationId divergente rejeitado"
    );

    let divResolved = false;
    let divRejected = false;
    divPromise.then(() => {
      divResolved = true;
    }).catch(() => {
      divRejected = true;
    });
    await new Promise((r) => setTimeout(r, 80));
    assert(divResolved === false, "T5b: promessa NÃO resolvida por correlationId divergente");
    try {
      await divPromise;
    } catch (_) {
      divRejected = true;
    }
    assert(divRejected === true, "T5b: promessa com correlationId divergente terminou em rejeição/timeout");

    // ----------------------------------------------------------------
    // T6: Integridade do payload (Worker-originated)
    // ----------------------------------------------------------------
    log("\n=== T6: Integridade do payload (Worker-originated) ===");
    const complexPayload = {
      numbers: [1, 2, 3],
      nested: { a: true, b: "hello", c: null },
      unicode: "日本語テスト"
    };
    const t6 = await workerEmit(bridge, workerA, "A", "B", "echo", complexPayload);
    assert(t6.type === "echo", "T6: tipo echo preservado");
    assert(
      JSON.stringify(t6.payload) === JSON.stringify(complexPayload),
      "T6: payload complexo idêntico após ida e volta"
    );

    // ----------------------------------------------------------------
    // T7: Volume originado pelos Workers
    // ----------------------------------------------------------------
    log("\n=== T7: Volume originado pelos Workers ===");
    const VOLUME = 200;
    const volumeStart = performance.now();
    const volumePromises = [];
    for (let i = 0; i < VOLUME; i++) {
      const fromWorker = i % 2 === 0 ? workerA : workerB;
      const origin = i % 2 === 0 ? "A" : "B";
      const destination = origin === "A" ? "B" : "A";
      volumePromises.push(
        workerEmit(bridge, fromWorker, origin, destination, "test", { i }, 15000)
      );
    }
    const volumeResults = await Promise.all(volumePromises);
    const volumeMs = performance.now() - volumeStart;
    assert(
      volumeResults.length === VOLUME,
      `T7: ${VOLUME} mensagens Worker-originated respondidas`
    );
    assert(
      volumeResults.every((r) => r && r.type === "ack"),
      "T7: todas as respostas são ack"
    );
    log(
      `T7: ${VOLUME} mensagens em ${volumeMs.toFixed(1)} ms (${(volumeMs / VOLUME).toFixed(2)} ms/msg)`
    );

    // ----------------------------------------------------------------
    // T8: Bridge não interfere nos comandos de emulação
    // ----------------------------------------------------------------
    log("\n=== T8: Bridge não interfere nos comandos de emulação ===");
    const beforeA = await workerA.request("stats");
    const beforeB = await workerB.request("stats");

    await Promise.all([
      workerEmit(bridge, workerA, "A", "B", "ping", { during: "frames" }),
      workerA.request("runFrame"),
      workerB.request("runFrame"),
      workerEmit(bridge, workerB, "B", "A", "ping", { during: "frames" })
    ]);

    const afterA = await workerA.request("stats");
    const afterB = await workerB.request("stats");

    assert(
      afterA.frameCounter === beforeA.frameCounter + 1,
      "T8: contador de frames de A avançou exatamente 1 apesar do tráfego da Bridge"
    );
    assert(
      afterB.frameCounter === beforeB.frameCounter + 1,
      "T8: contador de frames de B avançou exatamente 1 apesar do tráfego da Bridge"
    );

    await workerA.request("setKeys", { keys: 0x3 });
    const keysA = await workerA.request("getKeys");
    assert(keysA.keys === 0x3, "T8: setKeys/getKeys continuam funcionando em A");

    await workerB.request("setKeys", { keys: 0x5 });
    const keysB = await workerB.request("getKeys");
    assert(keysB.keys === 0x5, "T8: setKeys/getKeys continuam funcionando em B");

    // ----------------------------------------------------------------
    // Summary
    // ----------------------------------------------------------------
    log("\n========================================");
    log(`TESTES CONCLUÍDOS: ${passed} OK, ${failed} FALHAS`);
    if (failed === 0) {
      log("FASE 0.2.1 — Bridge: TODOS OS TESTES APROVADOS NESTA SESSÃO.", "ok");
    } else {
      log("Há falhas. Verifique o log acima.", "fail");
    }
    log(
      "Comunicação primária: Worker → bridgeEmit → bridgeOut → Bridge → destino.",
      "ok"
    );
    log("========================================");
  } catch (error) {
    log(`\nERRO: ${error instanceof Error ? error.message : String(error)}`, "fail");
    log("Os testes seguintes não foram considerados aprovados.", "fail");
    log(`Parcial: ${passed} OK, ${failed} FALHAS até o erro.`);
  } finally {
    runButton.disabled = false;
  }
});
