/**
 * Passthough Mashup V1 — Fase 0.3
 * The Minish Cap (USA) state adapter — READ ONLY.
 *
 * Evidence source: zeldaret/tmc decompilation (entity.h, linker symbols).
 *   gPlayerEntity @ 0x03001160 (IWRAM)
 *   Entity.x @ +0x2C (SplitWord Q16.16) → pixel = HALF.HI @ +0x2E
 *   Entity.y @ +0x30 → pixel HALF.HI @ +0x32
 *   Entity.animationState @ +0x14
 *   Entity.direction @ +0x15
 *   Entity.speed @ +0x24 (s16)
 *   gRoomControls @ 0x03000BF0 (camera / room metadata — partial)
 *
 * Confidence for position/direction/animation: HIGH (struct layout from decomp).
 * Live runtime confirmation still required on the user's ROM build.
 */

import { createEmptyGameState, CONFIDENCE } from "../schemas/GameStateSchema.js";
import { regionOf } from "../memory/MemoryReader.js";

/** Base address of gPlayerEntity (zeldaret/tmc linker.ld / DeepWiki). */
export const G_PLAYER_ENTITY = 0x03001160;

/** Offsets within Entity (include/entity.h). */
export const ENTITY_OFF = Object.freeze({
  animationState: 0x14,
  direction: 0x15,
  speed: 0x24,
  xWord: 0x2c,
  xPixel: 0x2e, // s16 HALF.HI of x
  yWord: 0x30,
  yPixel: 0x32 // s16 HALF.HI of y
});

/** gRoomControls base (camera / room). Field offsets partially documented. */
export const G_ROOM_CONTROLS = 0x03000BF0;

/**
 * Documented candidate addresses for Minish Cap.
 * Each entry is evidence-backed; none are invented.
 */
export const ZELDA_CANDIDATES = Object.freeze([
  {
    name: "link_x_pixel",
    address: G_PLAYER_ENTITY + ENTITY_OFF.xPixel,
    region: "IWRAM",
    size: 2,
    type: "s16",
    meaning: "Link X position in pixels (Entity.x.HALF.HI)",
    evidence:
      "zeldaret/tmc include/entity.h Entity.x at +0x2C Q16.16; HALF.HI at +0x2E. gPlayerEntity @ 0x03001160",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "link_y_pixel",
    address: G_PLAYER_ENTITY + ENTITY_OFF.yPixel,
    region: "IWRAM",
    size: 2,
    type: "s16",
    meaning: "Link Y position in pixels (Entity.y.HALF.HI)",
    evidence:
      "zeldaret/tmc include/entity.h Entity.y at +0x30 Q16.16; HALF.HI at +0x32. gPlayerEntity @ 0x03001160",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "link_animation_state",
    address: G_PLAYER_ENTITY + ENTITY_OFF.animationState,
    region: "IWRAM",
    size: 1,
    type: "u8",
    meaning: "AnimationState (0=N, 2=E, 4=S, 6=W idle facings)",
    evidence: "entity.h Entity.animationState at +0x14; AnimationState enum",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "link_direction",
    address: G_PLAYER_ENTITY + ENTITY_OFF.direction,
    region: "IWRAM",
    size: 1,
    type: "u8",
    meaning: "Facing direction (0x00 N … 0x1C NW, 8-way)",
    evidence: "entity.h Entity.direction at +0x15; Direction enum",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "link_speed",
    address: G_PLAYER_ENTITY + ENTITY_OFF.speed,
    region: "IWRAM",
    size: 2,
    type: "s16",
    meaning: "Movement speed magnitude",
    evidence: "entity.h Entity.speed at +0x24",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "room_controls_base",
    address: G_ROOM_CONTROLS,
    region: "IWRAM",
    size: 4,
    type: "struct",
    meaning: "gRoomControls base (camera/room metadata). Field map partially documented.",
    evidence: "zeldaret/tmc linker symbol gRoomControls @ 0x03000BF0",
    confidence: CONFIDENCE.MEDIUM
  }
]);

// AnimationState values documented for the four cardinal idle facings.
// We expose these as facing labels because the same value can remain present
// while the independent speed field reports movement.
const ANIM_FACING_LABEL = Object.freeze({
  0: "north",
  2: "east",
  4: "south",
  6: "west"
});

const DIRECTION_LABEL = Object.freeze({
  0x00: "north",
  0x04: "north_east",
  0x08: "east",
  0x0c: "south_east",
  0x10: "south",
  0x14: "south_west",
  0x18: "west",
  0x1c: "north_west"
});

function directionLabel(value) {
  return Object.prototype.hasOwnProperty.call(DIRECTION_LABEL, value)
    ? DIRECTION_LABEL[value]
    : null;
}

export class ZeldaStateAdapter {
  /**
   * @param {import("../memory/MemoryReader.js").MemoryReader} reader
   */
  constructor(reader) {
    this._reader = reader;
    this._lastValidDirection = null;
  }

  /** @returns {typeof ZELDA_CANDIDATES} */
  getCandidates() {
    return ZELDA_CANDIDATES;
  }

  /**
   * Snapshot Link-related state via read-only memory access.
   * @returns {Promise<object>}
   */
  async readState() {
    const state = createEmptyGameState("zelda");
    const r = this._reader;

    try {
      const x = await r.readS16(G_PLAYER_ENTITY + ENTITY_OFF.xPixel);
      const y = await r.readS16(G_PLAYER_ENTITY + ENTITY_OFF.yPixel);
      const anim = await r.read8(G_PLAYER_ENTITY + ENTITY_OFF.animationState);
      const dir = await r.read8(G_PLAYER_ENTITY + ENTITY_OFF.direction);
      const speed = await r.readS16(G_PLAYER_ENTITY + ENTITY_OFF.speed);

      state.position = { x, y };
      const animationFacing = Object.prototype.hasOwnProperty.call(ANIM_FACING_LABEL, anim)
        ? ANIM_FACING_LABEL[anim]
        : null;
      state.animationState = animationFacing ? `facing_${animationFacing}` : `raw_${anim}`;
      state.speed = speed;
      state.movementState = speed !== 0 ? "moving" : "idle";

      // The direction byte is valid while Link moves, but the user's live test
      // observed 0xFF while standing still. Prefer the documented cardinal
      // facing encoded by AnimationState in that case; retain last known
      // direction only as a lower-confidence final fallback.
      const directDirection = directionLabel(dir);
      let directionSource = "unavailable";
      if (directDirection) {
        state.direction = directDirection;
        this._lastValidDirection = directDirection;
        directionSource = "directionByte";
      } else if (animationFacing) {
        state.direction = animationFacing;
        this._lastValidDirection = animationFacing;
        directionSource = "animationStateFallback";
      } else if (this._lastValidDirection) {
        state.direction = this._lastValidDirection;
        directionSource = "lastKnownDirection";
      }

      state.raw = {
        xPixel: x,
        yPixel: y,
        animationStateByte: anim,
        directionByte: dir,
        directionSource,
        speed,
        gPlayerEntity: G_PLAYER_ENTITY,
        region: regionOf(G_PLAYER_ENTITY)
      };

      state.confidence = {
        position: CONFIDENCE.HIGH,
        direction: directionSource === "directionByte"
          ? CONFIDENCE.HIGH
          : directionSource === "animationStateFallback"
            ? CONFIDENCE.MEDIUM
            : directionSource === "lastKnownDirection"
              ? CONFIDENCE.LOW
              : CONFIDENCE.NONE,
        animationState: CONFIDENCE.HIGH,
        movementState: CONFIDENCE.MEDIUM,
        speed: CONFIDENCE.HIGH,
        mapId: CONFIDENCE.NONE,
        camera: CONFIDENCE.NONE
      };

      state.notes.push(
        "Addresses from zeldaret/tmc Entity layout. Runtime values depend on game being in active gameplay (not title/menu)."
      );
      if (directionSource === "animationStateFallback") {
        state.notes.push("Direction byte was not mapped; cardinal facing was inferred from the documented AnimationState value.");
      } else if (directionSource === "lastKnownDirection") {
        state.notes.push("Direction byte and AnimationState were not mapped; showing the last valid direction with low confidence.");
      } else if (directionSource === "unavailable") {
        state.notes.push("Direction could not be determined from the current memory snapshot.");
      }
    } catch (err) {
      state.notes.push(
        `Read failed: ${err instanceof Error ? err.message : String(err)}`
      );
      state.confidence = {
        position: CONFIDENCE.NONE,
        direction: CONFIDENCE.NONE,
        animationState: CONFIDENCE.NONE
      };
    }

    state.timestamp = Date.now();
    return state;
  }
}
