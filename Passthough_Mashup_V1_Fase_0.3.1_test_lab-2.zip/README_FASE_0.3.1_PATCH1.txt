Passthough Mashup V1 — Fase 0.3.1 Patch 1

Conteúdo:
- tests/phase0_3_1.html: painel com atualização automática configurável e troca de perfil durante a sessão.
- tests/phase0_3_1.js: perfil dinâmico e atualização automática visível (500 ms).
- src/state/adapters/ZeldaStateAdapter.js: fallback de direção para o estado parado.

Correção Zelda:
- Quando directionByte contém um valor mapeado, ele continua sendo a fonte principal.
- Quando directionByte não é mapeado (ex.: 0xFF observado no teste parado), o adaptador tenta obter a orientação cardinal do AnimationState documentado (0=N, 2=E, 4=S, 6=W).
- Se ambos forem inválidos, pode exibir a última direção válida, com confiança LOW e origem explícita no raw.directionSource.
- Se não houver direção conhecida, o campo permanece null; o byte bruto continua disponível.
- A animação é exibida como facing_north/east/south/west para não contradizer movementState=moving.

Integração no workflow:
Na etapa "Aplicar Test Lab da Fase 0.3.1", além de copiar os dois arquivos de tests, acrescente:
  cp -a /tmp/phase031/Passthough-Mashup-V1-Fase-0.1/src/state/adapters/ZeldaStateAdapter.js ./src/state/adapters/

Não altera emulator.worker.js, WASM, Bridge, nem os testes das fases anteriores.

Validação realizada nesta preparação:
- Sintaxe JavaScript validada com Node.js.
- Teste isolado do adaptador para directionByte=0xFF e animationState=2 => east via animationStateFallback.
- Teste isolado de direção direta e fallback de última direção.
- Ainda requer teste no navegador com ROM real para confirmação final.
