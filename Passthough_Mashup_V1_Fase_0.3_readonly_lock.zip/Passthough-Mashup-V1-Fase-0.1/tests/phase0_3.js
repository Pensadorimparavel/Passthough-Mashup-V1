/**
 * Passthough Mashup V1 — Fase 0.3
 * Read-only state extraction tests + regression of 0.1 / Bridge smoke.
 */

import { MemoryReader } from "../src/state/memory/MemoryReader.js";
import { ZeldaStateAdapter, ZELDA_CANDIDATES } from "../src/state/adapters/ZeldaStateAdapter.js";
import { BuuFuryStateAdapter, BUU_CANDIDATES, BUU_UNIDENTIFIED } from "../src/state/adapters/BuuFuryStateAdapter.js";
import { Bridge } from "../src/bridge/Bridge.js";
import { createEnvelope } from "../src/bridge/MessageProtocol.js";

const logElement = document.querySelector("#log");
const runButton = document.querySelector("#runTests");
const sampleButton = document.querySelector("#sampleStates");
const stopButton = document.querySelector("#stopWorkers");
const romAInput = document.querySelector("#romA");
const romBInput = document.querySelector("#romB");

let workers = [];
let bridge = null;
let passed = 0;
let failed = 0;

function log(message, cls = "") {
  const line = document.createElement("div");
  if (cls) line.className = cls;
  line.textContent = message;
  logElement.appendChild(line);
  logElement.scrollTop = logElement.scrollHeight;
}

function assert(condition, message) {
  if (!condition) {
    failed += 1;
    log(`FALHOU: ${message}`, "fail");
    throw new Error(`FALHOU: ${message}`);
  }
  passed += 1;
  log(`OK: ${message}`, "ok");
}

function makeWorker() {
  const worker = new Worker(
    new URL("../src/workers/emulator.worker.js", import.meta.url),
    { type: "module" }
  );
  let nextId = 1;
  const pending = new Map();

  worker.onmessage = (event) => {
    const message = event.data;
    if (message && (message.type === "bridgeOut" || message.type === "bridgeResponse")) {
      return;
    }
    const item = pending.get(message.id);
    if (!item) return;
    pending.delete(message.id);
    if (message.ok) item.resolve(message);
    else item.reject(new Error(message.error || "Erro no worker."));
  };

  worker.onerror = (event) => {
    for (const item of pending.values()) item.reject(new Error(event.message));
    pending.clear();
  };

  return {
    raw: worker,
    request(type, payload = {}, transfer = []) {
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        worker.postMessage({ id, type, ...payload }, transfer);
      });
    },
    terminate() {
      worker.terminate();
      for (const item of pending.values()) item.reject(new Error("Worker encerrado."));
      pending.clear();
    }
  };
}

async function readFile(input, fallback) {
  const file = input.files?.[0] || fallback;
  if (!file) throw new Error("Selecione ROMs GBA para A e B.");
  return file.arrayBuffer();
}

function stopAll() {
  if (bridge) {
    bridge.destroy();
    bridge = null;
  }
  for (const w of workers) w.terminate();
  workers = [];
}

stopButton.addEventListener("click", () => {
  stopAll();
  log("Workers encerrados.");
});

runButton.addEventListener("click", async () => {
  runButton.disabled = true;
  stopAll();
  logElement.textContent = "";
  passed = 0;
  failed = 0;

  try {
    log("=== Bootstrap + regressão 0.1 ===");
    const romA = await readFile(romAInput);
    const romB = await readFile(romBInput, romAInput.files?.[0]);

    const workerA = makeWorker();
    const workerB = makeWorker();
    workers = [workerA, workerB];

    await Promise.all([workerA.request("init"), workerB.request("init")]);
    await Promise.all([
      workerA.request("loadRom", { rom: romA }, [romA]),
      workerB.request("loadRom", { rom: romB }, [romB])
    ]);
    const [fA, fB] = await Promise.all([
      workerA.request("runFrame"),
      workerB.request("runFrame")
    ]);
    assert(fA.frameCounter === fA.beforeFrameCounter + 1, "regressão: frame A");
    assert(fB.frameCounter === fB.beforeFrameCounter + 1, "regressão: frame B");

    // --- MemoryReader read-only + monotonic Worker boundary policy ---
    log("\n=== MemoryReader + trava irreversível de escrita no Worker ===");
    const readerA = new MemoryReader(workerA);
    const readerB = new MemoryReader(workerB);

    const ewram = await readerA.read8(0x02000000);
    assert(typeof ewram === "number", "leitura EWRAM 0x02000000 retornou byte");
    const iwram = await readerA.read8(0x03000000);
    assert(typeof iwram === "number", "leitura IWRAM 0x03000000 retornou byte");

    // Class-level guard (MemoryReader.write8 always throws)
    let writeBlocked = false;
    try {
      await readerA.write8(0x02000000, 0);
    } catch (e) {
      writeBlocked = String(e.message).includes("read-only");
    }
    assert(writeBlocked, "MemoryReader bloqueia escrita na classe");
    assert(readerA.blockedWriteAttempts >= 1, "contador de escritas bloqueadas incrementou");

    // Fresh independent Worker: default true and write/readback preserve Phase 0.1 behavior.
    const legacyWorker = makeWorker();
    workers.push(legacyWorker);
    await legacyWorker.request("init");
    const legacyRom = await readFile(romAInput);
    await legacyWorker.request("loadRom", { rom: legacyRom }, [legacyRom]);
    const legacyPolicy = await legacyWorker.request("getMemoryWriteEnabled");
    assert(
      legacyPolicy.memoryWriteEnabled === true && legacyPolicy.memoryWriteLocked === false,
      "Worker independente inicia com escrita habilitada (compatibilidade Fase 0.1)"
    );
    const legacyAddress = 0x02000000;
    const legacyOriginal = await legacyWorker.request("readMemory8", { address: legacyAddress });
    const legacyTestValue = legacyOriginal.value ^ 0xff;
    await legacyWorker.request("writeMemory8", { address: legacyAddress, value: legacyTestValue });
    const legacyReadback = await legacyWorker.request("readMemory8", { address: legacyAddress });
    assert(
      legacyReadback.value === legacyTestValue,
      "Worker independente ainda aceita escrita real na sessão padrão da Fase 0.1"
    );
    await legacyWorker.request("writeMemory8", { address: legacyAddress, value: legacyOriginal.value });
    legacyWorker.terminate();
    workers = workers.filter((w) => w !== legacyWorker);

    // Lock both gameplay Workers before adapters/state extraction are created.
    await readerA.enableReadOnlyPolicy();
    await readerB.enableReadOnlyPolicy();
    const policyA = await readerA.getWritePolicyState();
    const policyB = await readerB.getWritePolicyState();
    assert(
      policyA.memoryWriteEnabled === false && policyA.memoryWriteLocked === true,
      "Worker A: trava irreversível confirmada"
    );
    assert(
      policyB.memoryWriteEnabled === false && policyB.memoryWriteLocked === true,
      "Worker B: trava irreversível confirmada"
    );

    let workerWriteBlocked = false;
    try {
      await workerA.request("writeMemory8", { address: 0x02000000, value: 0 });
    } catch (e) {
      workerWriteBlocked = String(e.message).includes("read-only");
    }
    assert(
      workerWriteBlocked,
      "Worker rejeita writeMemory8 após ativação da trava read-only"
    );

    let reenableARejected = false;
    try {
      await workerA.request("setMemoryWriteEnabled", { enabled: true });
    } catch (e) {
      reenableARejected = String(e.message).includes("one-way") || String(e.message).includes("re-enabled");
    }
    assert(reenableARejected, "Worker A rejeita tentativa de reativar escrita");

    let reenableBRejected = false;
    try {
      await workerB.request("setMemoryWriteEnabled", { enabled: true });
    } catch (e) {
      reenableBRejected = String(e.message).includes("one-way") || String(e.message).includes("re-enabled");
    }
    assert(reenableBRejected, "Worker B rejeita tentativa de reativar escrita");

    const [policyAAfter, policyBAfter] = await Promise.all([
      readerA.getWritePolicyState(),
      readerB.getWritePolicyState()
    ]);
    assert(
      policyAAfter.memoryWriteEnabled === false && policyAAfter.memoryWriteLocked === true,
      "Worker A permanece bloqueado após tentativa de reativação"
    );
    assert(
      policyBAfter.memoryWriteEnabled === false && policyBAfter.memoryWriteLocked === true,
      "Worker B permanece bloqueado após tentativa de reativação"
    );

    const stillRead = await readerA.read8(0x03000000);
    assert(typeof stillRead === "number", "leitura continua funcionando sob trava read-only");

    // --- Candidates documented ---
    log("\n=== Candidatos documentados ===");
    assert(ZELDA_CANDIDATES.length >= 5, "Zelda possui candidatos de decomp");
    assert(
      ZELDA_CANDIDATES.every((c) => c.evidence && c.address),
      "cada candidato Zelda tem endereço e evidência"
    );
    assert(BUU_CANDIDATES.length >= 3, "Buu possui candidatos Data Crystal");
    assert(BUU_UNIDENTIFIED.length >= 1, "Buu declara gaps de posição");
    assert(
      BUU_UNIDENTIFIED.some((u) => u.name.includes("world_x")),
      "posição X de Buu marcada como não identificada"
    );

    // --- Adapters ---
    log("\n=== Adaptadores ===");
    const zelda = new ZeldaStateAdapter(readerA);
    const buu = new BuuFuryStateAdapter(readerB);

    // Advance some frames so cores are past pure reset if possible
    await Promise.all([
      workerA.request("runFrames", { count: 30 }),
      workerB.request("runFrames", { count: 30 })
    ]);

    const zState = await zelda.readState();
    assert(zState.game === "zelda", "estado Zelda: game=zelda");
    assert(zState.confidence.position === "high", "Zelda position confidence high (decomp)");
    assert(
      typeof zState.position.x === "number" && typeof zState.position.y === "number",
      "Zelda position x/y numéricos (valores brutos da RAM)"
    );
    log(
      `Zelda sample: x=${zState.position.x} y=${zState.position.y} dir=${zState.direction} anim=${zState.animationState} speed=${zState.speed}`,
      "warn"
    );
    log(
      "Nota: em title/menu os valores podem ser 0 ou lixo; confiar só após gameplay ativo.",
      "warn"
    );

    const bState = await buu.readState();
    assert(bState.game === "buus_fury", "estado Buu: game=buus_fury");
    assert(bState.position.x === null && bState.position.y === null, "Buu position permanece null");
    assert(bState.confidence.position === "none", "Buu position confidence none");
    assert(bState.confidence.hp === "high" || bState.hp !== null || bState.notes.length > 0, "Buu HP path exercitado");
    log(
      `Buu sample: char=${bState.currentCharacter} hp=${bState.hp}/${bState.maxHp} (posição: não identificada)`,
      "warn"
    );

    // --- Frames not disturbed by reads ---
    log("\n=== Leituras não interrompem frames ===");
    const before = await workerA.request("stats");
    await zelda.readState();
    await workerA.request("runFrame");
    const after = await workerA.request("stats");
    assert(
      after.frameCounter === before.frameCounter + 1,
      "após leituras de estado, runFrame ainda avança 1"
    );

    // --- Bridge smoke (0.2.1 regression light) ---
    log("\n=== Bridge smoke ===");
    bridge = new Bridge(workerA, workerB, { onReject: () => {} });
    const env = createEnvelope({
      origin: "A",
      destination: "B",
      type: "ping",
      payload: { phase: "0.3" }
    });
    const respP = bridge.expectResponse(env.messageId, 5000);
    await workerA.request("bridgeEmit", { envelope: env });
    const resp = await respP;
    assert(resp.type === "pong", "Bridge A→B ainda funciona após Fase 0.3");

    log("\n========================================");
    log(`FASE 0.3 TESTES: ${passed} OK, ${failed} FALHAS`);
    if (failed === 0) {
      log("Testes automatizados desta sessão: APROVADOS.", "ok");
      log(
        "LIMITAÇÃO: posição de Buu's Fury NÃO está resolvida — ver ADDRESS_MAP.md",
        "warn"
      );
    }
    log("========================================");
  } catch (error) {
    log(`\nERRO: ${error instanceof Error ? error.message : String(error)}`, "fail");
    log(`Parcial: ${passed} OK, ${failed} FALHAS`);
  } finally {
    runButton.disabled = false;
  }
});

sampleButton.addEventListener("click", async () => {
  if (workers.length < 2) {
    log("Inicialize os workers pelo botão de testes primeiro.", "fail");
    return;
  }
  const readerA = new MemoryReader(workers[0]);
  const readerB = new MemoryReader(workers[1]);
  const zelda = new ZeldaStateAdapter(readerA);
  const buu = new BuuFuryStateAdapter(readerB);
  const z = await zelda.readState();
  const b = await buu.readState();
  log("\n--- Sample Zelda ---\n" + JSON.stringify(z, null, 2));
  log("\n--- Sample Buu ---\n" + JSON.stringify(b, null, 2));
});
