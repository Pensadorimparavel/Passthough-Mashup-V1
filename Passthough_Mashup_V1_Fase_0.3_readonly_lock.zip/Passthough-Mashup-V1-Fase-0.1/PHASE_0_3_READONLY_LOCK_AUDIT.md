# Fase 0.3 — auditoria da trava somente leitura

## Correção aplicada

A política de escrita do Worker agora é monotônica por sessão:

- Um Worker recém-criado começa com `memoryWriteEnabled = true` e `memoryWriteLocked = false`, preservando a compatibilidade com a Fase 0.1.
- `setMemoryWriteEnabled` aceita somente `enabled: false`.
- Ao receber `enabled: false`, o Worker define `memoryWriteEnabled = false` e `memoryWriteLocked = true`.
- Qualquer tentativa de enviar `enabled: true` é rejeitada.
- `writeMemory8` continua disponível em Workers independentes que ainda não ativaram a trava, mas é rejeitado após a ativação da política read-only.
- A trava não pode ser desfeita dentro da mesma sessão do Worker. Encerrar o Worker e criar outro inicia uma sessão independente, com o padrão legado.

## Arquivos alterados

1. `src/workers/emulator.worker.js`
   - Adicionada a flag `memoryWriteLocked`.
   - `setMemoryWriteEnabled` convertido de toggle em trava de mão única.
   - `getMemoryWriteEnabled` agora informa também `memoryWriteLocked`.

2. `src/state/memory/MemoryReader.js`
   - `enableReadOnlyPolicy()` verifica se o Worker confirmou a trava.
   - Adicionado `getWritePolicyState()` para consultar os dois estados.
   - `getWritePolicy()` preserva o retorno booleano anterior.

3. `tests/phase0_3.js`
   - Adicionado Worker independente para verificar o padrão legado da Fase 0.1 e uma escrita/leitura real com ROM carregada.
   - Adicionados testes de bloqueio de escrita em A e B.
   - Adicionados testes de rejeição de reativação em A e B.
   - Adicionada verificação de que ambos permanecem bloqueados e continuam permitindo leituras.

4. `README.md`
   - Documentada a política de escrita por sessão.

## Verificações realizadas neste ambiente

- Sintaxe JavaScript: **11 arquivos verificados, sem erros** (`node --check`).
- Inspeção estática: o único caminho do Worker que chama `_mgba_write_memory8` é `writeMemory8`, protegido pela flag `memoryWriteEnabled`.
- Inspeção estática: a política só pode transitar de habilitada para desabilitada; não há caminho de reativação no Worker.
- Teste isolado do Worker com núcleo mGBA simulado: **9 verificações passaram**, incluindo padrão inicial habilitado, escrita legada permitida, trava, escrita bloqueada, reativação rejeitada, persistência da trava e leitura preservada. Esse teste valida a lógica do Worker, não substitui o teste no navegador com o WASM real.

## Verificações ainda não executadas

- Suite `tests/phase0_3.html` em navegador com ROMs e WebAssembly.
- Regressão completa das Fases 0.1 e 0.2.1 em navegador.

O ZIP de origem não contém `wasm/mgba_wasm.mjs` nem `wasm/mgba_wasm.wasm`; portanto, os testes reais de navegador não puderam ser executados neste ambiente. A aprovação runtime depende da execução no ambiente publicado com os artefatos WASM e ROMs legítimas do usuário.

## Status

Correção estática da trava irreversível implementada. **Fase 0.3 permanece parcialmente concluída**: posição X/Y de Buu's Fury não identificada e validação em gameplay real ainda pendente.
