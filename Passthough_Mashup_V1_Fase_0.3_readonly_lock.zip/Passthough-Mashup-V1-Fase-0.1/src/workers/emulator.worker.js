import createMGBA from "../../wasm/mgba_wasm.mjs";

let moduleInstance = null;
let coreHandle = 0;
let ready = false;
/**
 * Write policy is session-scoped and monotonic.
 * Fresh Workers default to enabled for Fase 0.1 compatibility.
 * Fase 0.3 may lock writes off once; this Worker cannot unlock them again.
 */
let memoryWriteEnabled = true;
let memoryWriteLocked = false;

function reply(id, ok, payload = {}, transfer = []) {
  self.postMessage({ id, ok, ...payload }, transfer);
}

function requireReady() {
  if (!ready || !moduleInstance || !coreHandle) {
    throw new Error("O worker ainda não inicializou o núcleo mGBA.");
  }
}

/**
 * Fase 0.2.1 — process an incoming bridge envelope delivered by the main-thread Bridge.
 * Supports only the simple types defined for this phase (ping/pong/echo/ack/test/status).
 * Does not touch the mGBA core.
 */
function handleIncomingBridge(envelope) {
  if (!envelope || typeof envelope !== "object") {
    self.postMessage({
      type: "bridgeResponse",
      inReplyTo: null,
      envelope: {
        protocolVersion: 1,
        messageId: `err_${Date.now()}`,
        origin: "?",
        destination: "?",
        type: "ack",
        timestamp: Date.now(),
        payload: { error: true, reason: "Missing or invalid envelope" }
      }
    });
    return;
  }

  const inReplyTo = envelope.messageId;
  let responseType = "ack";
  let responsePayload = { received: true, originalType: envelope.type };

  switch (envelope.type) {
    case "ping":
      responseType = "pong";
      responsePayload = { pong: true, echo: envelope.payload };
      break;
    case "echo":
      responseType = "echo";
      responsePayload = envelope.payload;
      break;
    case "test":
    case "status":
    case "ack":
    case "pong":
      responseType = "ack";
      responsePayload = { received: true, originalType: envelope.type, originalPayload: envelope.payload };
      break;
    default:
      responseType = "ack";
      responsePayload = { error: true, reason: `Unsupported bridge type in worker: ${envelope.type}` };
      break;
  }

  self.postMessage({
    type: "bridgeResponse",
    inReplyTo,
    envelope: {
      protocolVersion: 1,
      messageId: `resp_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`,
      origin: envelope.destination, // this worker is the destination of the original
      destination: envelope.origin,
      type: responseType,
      timestamp: Date.now(),
      payload: responsePayload,
      correlationId: inReplyTo
    }
  });
}

self.onmessage = async (event) => {
  const message = event.data || {};
  const { id, type } = message;

  try {
    // ------------------------------------------------------------------
    // Fase 0.2.1 — dedicated Bridge channel (completely separate from
    // emulator commands: init / loadRom / runFrame / setKeys / etc.)
    // ------------------------------------------------------------------
    if (type === "bridge") {
      handleIncomingBridge(message.envelope);
      return;
    }

    if (type === "bridgeEmit") {
      // Main asks this Worker to emit a bridge message (used by tests).
      // The real origin will be forced by the Bridge on the main thread.
      const envelope = message.envelope;
      if (!envelope || typeof envelope !== "object") {
        throw new Error("bridgeEmit requires a valid envelope object");
      }
      self.postMessage({
        type: "bridgeOut",
        envelope
      });
      if (id !== undefined) {
        reply(id, true, { type: "bridgeEmitted", messageId: envelope.messageId });
      }
      return;
    }

    if (type === "bridgeForgeResponse") {
      // Test-only: post a crafted bridgeResponse from this Worker.
      // Used to verify the Bridge rejects wrong responder / bad correlation.
      self.postMessage({
        type: "bridgeResponse",
        inReplyTo: message.inReplyTo,
        envelope: message.envelope
      });
      if (id !== undefined) {
        reply(id, true, { type: "bridgeForged" });
      }
      return;
    }

    if (type === "init") {
      if (ready) {
        reply(id, true, { type: "ready", memoryBytes: moduleInstance.HEAPU8.buffer.byteLength });
        return;
      }
      moduleInstance = await createMGBA();
      coreHandle = moduleInstance._mgba_create();
      if (!coreHandle) throw new Error("mgba_create() falhou.");
      ready = true;
      reply(id, true, {
        type: "ready",
        memoryBytes: moduleInstance.HEAPU8.buffer.byteLength
      });
      return;
    }

    requireReady();

    if (type === "loadRom") {
      const bytes = new Uint8Array(message.rom);
      const ptr = moduleInstance._malloc(bytes.byteLength);
      if (!ptr) throw new Error("Falha ao alocar memória temporária para a ROM.");
      try {
        moduleInstance.HEAPU8.set(bytes, ptr);
        const loaded = moduleInstance._mgba_load_rom(coreHandle, ptr, bytes.byteLength);
        if (!loaded) throw new Error("O núcleo mGBA recusou a ROM GBA fornecida.");
      } finally {
        moduleInstance._free(ptr);
      }
      reply(id, true, { type: "romLoaded", romBytes: bytes.byteLength });
      return;
    }

    if (type === "runFrame") {
      const beforeFrameCounter = moduleInstance._mgba_get_frame_counter(coreHandle);
      const start = performance.now();
      const ran = moduleInstance._mgba_run_frame(coreHandle);
      const durationMs = performance.now() - start;
      if (!ran) throw new Error("runFrame requer uma ROM carregada.");
      reply(id, true, {
        type: "frame",
        beforeFrameCounter,
        frameCounter: moduleInstance._mgba_get_frame_counter(coreHandle),
        durationMs
      });
      return;
    }

    if (type === "runFrames") {
      const count = Math.max(1, Math.min(10000, Number(message.count) || 1));
      const start = performance.now();
      for (let i = 0; i < count; i++) {
        if (!moduleInstance._mgba_run_frame(coreHandle)) {
          throw new Error("Não foi possível executar frame; confira se a ROM foi carregada.");
        }
      }
      const durationMs = performance.now() - start;
      reply(id, true, {
        type: "frames",
        count,
        durationMs,
        averageMsPerFrame: durationMs / count,
        frameCounter: moduleInstance._mgba_get_frame_counter(coreHandle),
        memoryBytes: moduleInstance.HEAPU8.buffer.byteLength
      });
      return;
    }

    if (type === "setKeys") {
      moduleInstance._mgba_set_keys(coreHandle, Number(message.keys) >>> 0);
      reply(id, true, { type: "keysSet" });
      return;
    }

    if (type === "getKeys") {
      reply(id, true, {
        type: "keys",
        keys: moduleInstance._mgba_get_keys(coreHandle)
      });
      return;
    }

    if (type === "readMemory8") {
      const value = moduleInstance._mgba_read_memory8(
        coreHandle, Number(message.address) >>> 0
      );
      reply(id, true, { type: "memoryValue", value });
      return;
    }

    if (type === "setMemoryWriteEnabled") {
      // This is deliberately a one-way lock, not a general-purpose toggle.
      // A fresh Worker remains write-enabled for the Phase 0.1 regression.
      // Phase 0.3 can only request enabled:false. No message can unlock it.
      if (message.enabled !== false) {
        throw new Error(
          "memory write policy is one-way: only enabled:false is accepted; writes cannot be re-enabled in this Worker session"
        );
      }
      memoryWriteEnabled = false;
      memoryWriteLocked = true;
      reply(id, true, {
        type: "memoryWritePolicy",
        memoryWriteEnabled,
        memoryWriteLocked
      });
      return;
    }

    if (type === "getMemoryWriteEnabled") {
      reply(id, true, {
        type: "memoryWritePolicy",
        memoryWriteEnabled,
        memoryWriteLocked
      });
      return;
    }

    if (type === "writeMemory8") {
      // Boundary guard for Fase 0.3 read-only sessions.
      // Fase 0.1 keeps the default (enabled) so its regression tests still work.
      if (!memoryWriteEnabled) {
        throw new Error(
          "writeMemory8 blocked: memory write policy is read-only (Fase 0.3)"
        );
      }
      const wrote = moduleInstance._mgba_write_memory8(
        coreHandle,
        Number(message.address) >>> 0,
        Number(message.value) & 0xff
      );
      if (!wrote) throw new Error("Falha ao escrever na memória.");
      reply(id, true, { type: "memoryWritten" });
      return;
    }

    if (type === "framebuffer") {
      const ptr = moduleInstance._mgba_get_framebuffer_ptr(coreHandle);
      const size = moduleInstance._mgba_get_framebuffer_size(coreHandle);
      const width = moduleInstance._mgba_get_framebuffer_width(coreHandle);
      const height = moduleInstance._mgba_get_framebuffer_height(coreHandle);
      const bytes = moduleInstance.HEAPU8.slice(ptr, ptr + size);
      reply(id, true, {
        type: "framebuffer",
        width,
        height,
        byteLength: bytes.byteLength,
        format: "mColor nativo (build 32-bit; mCOLOR_XBGR8)",
        pixels: bytes.buffer
      }, [bytes.buffer]);
      return;
    }

    if (type === "stats") {
      reply(id, true, {
        type: "stats",
        memoryBytes: moduleInstance.HEAPU8.buffer.byteLength,
        frameCounter: moduleInstance._mgba_get_frame_counter(coreHandle)
      });
      return;
    }

    if (type === "destroy") {
      moduleInstance._mgba_destroy(coreHandle);
      coreHandle = 0;
      ready = false;
      moduleInstance = null;
      reply(id, true, { type: "destroyed" });
      self.close();
      return;
    }

    throw new Error(`Comando desconhecido: ${String(type)}`);
  } catch (error) {
    reply(id, false, { error: error instanceof Error ? error.message : String(error) });
  }
};
