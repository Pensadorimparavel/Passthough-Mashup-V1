/**
 * Passthough Mashup V1 — Fase 0.3
 * Common schema for extracted game state (read-only).
 * Fields remain null until backed by verified memory evidence.
 */

/**
 * @typedef {"low"|"medium"|"high"|"none"} Confidence
 */

/**
 * @typedef {object} ConfidenceMap
 * @property {Confidence} [position]
 * @property {Confidence} [direction]
 * @property {Confidence} [movementState]
 * @property {Confidence} [animationState]
 * @property {Confidence} [mapId]
 * @property {Confidence} [camera]
 * @property {Confidence} [speed]
 * @property {Confidence} [combat]
 * @property {Confidence} [hp]
 * @property {Confidence} [currentCharacter]
 */

/**
 * @returns {object}
 */
export function createEmptyGameState(game) {
  return {
    game, // "zelda" | "buus_fury"
    position: { x: null, y: null },
    direction: null,
    movementState: null,
    animationState: null,
    mapId: null,
    camera: { x: null, y: null },
    speed: null,
    combat: null,
    hp: null,
    maxHp: null,
    currentCharacter: null,
    raw: {},
    confidence: {},
    timestamp: Date.now(),
    notes: []
  };
}

/**
 * Confidence levels used in documentation and adapters.
 * - high: backed by decompilation / published struct layout
 * - medium: strong correlational evidence, not yet struct-proven
 * - low: candidate only, needs live verification
 * - none: not identified
 */
export const CONFIDENCE = Object.freeze({
  HIGH: "high",
  MEDIUM: "medium",
  LOW: "low",
  NONE: "none"
});
