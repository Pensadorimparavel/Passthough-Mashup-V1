/**
 * Passthough Mashup V1 — Fase 0.3
 * Read-only memory access via the existing emulator Worker protocol.
 *
 * Uses ONLY: readMemory8 (and multi-byte helpers built on top of it).
 * NEVER calls writeMemory8 or any write path.
 */

/** GBA memory region helpers (informational). */
export const REGION = Object.freeze({
  EWRAM: { start: 0x02000000, end: 0x02040000, name: "EWRAM" },
  IWRAM: { start: 0x03000000, end: 0x03008000, name: "IWRAM" },
  IO: { start: 0x04000000, end: 0x04000400, name: "IO" },
  PALETTE: { start: 0x05000000, end: 0x05000400, name: "PALETTE" },
  VRAM: { start: 0x06000000, end: 0x06018000, name: "VRAM" },
  OAM: { start: 0x07000000, end: 0x07000400, name: "OAM" }
});

export function regionOf(address) {
  const a = address >>> 0;
  for (const r of Object.values(REGION)) {
    if (a >= r.start && a < r.end) return r.name;
  }
  return "UNKNOWN";
}

/**
 * @param {object} workerWrapper - object with request(type, payload) from Phase 0.1
 */
export class MemoryReader {
  constructor(workerWrapper) {
    if (!workerWrapper || typeof workerWrapper.request !== "function") {
      throw new Error("MemoryReader requires a worker wrapper with request()");
    }
    this._worker = workerWrapper;
    this._writeAttemptBlocked = 0;
    this._policyLocked = false;
  }

  /**
   * Lock the underlying Worker to read-only memory policy.
   * writeMemory8 is then rejected at the Worker boundary, not only in this class.
   * Call once when starting Fase 0.3 state extraction on a worker.
   */
  async enableReadOnlyPolicy() {
    const res = await this._worker.request("setMemoryWriteEnabled", { enabled: false });
    if (res.memoryWriteEnabled !== false || res.memoryWriteLocked !== true) {
      throw new Error("Worker não confirmou a trava irreversível de escrita.");
    }
    this._policyLocked = true;
    return true;
  }

  async getWritePolicy() {
    const state = await this.getWritePolicyState();
    return state.memoryWriteEnabled;
  }

  async getWritePolicyState() {
    const res = await this._worker.request("getMemoryWriteEnabled");
    return {
      memoryWriteEnabled: Boolean(res.memoryWriteEnabled),
      memoryWriteLocked: Boolean(res.memoryWriteLocked)
    };
  }

  /** @returns {Promise<number>} unsigned byte 0..255 */
  async read8(address) {
    const res = await this._worker.request("readMemory8", {
      address: address >>> 0
    });
    return res.value & 0xff;
  }

  /** Little-endian u16 */
  async read16(address) {
    const lo = await this.read8(address);
    const hi = await this.read8(address + 1);
    return (lo | (hi << 8)) >>> 0;
  }

  /** Little-endian u32 */
  async read32(address) {
    const b0 = await this.read8(address);
    const b1 = await this.read8(address + 1);
    const b2 = await this.read8(address + 2);
    const b3 = await this.read8(address + 3);
    return (b0 | (b1 << 8) | (b2 << 16) | (b3 << 24)) >>> 0;
  }

  /** Little-endian signed s16 */
  async readS16(address) {
    const u = await this.read16(address);
    return u > 0x7fff ? u - 0x10000 : u;
  }

  /** Little-endian signed s32 */
  async readS32(address) {
    const u = await this.read32(address);
    return u > 0x7fffffff ? u - 0x100000000 : u;
  }

  /**
   * Read a contiguous block of bytes (sequential read8).
   * @param {number} address
   * @param {number} length
   * @returns {Promise<Uint8Array>}
   */
  async readBytes(address, length) {
    const out = new Uint8Array(length);
    for (let i = 0; i < length; i++) {
      out[i] = await this.read8(address + i);
    }
    return out;
  }

  /**
   * Explicitly refuse any write request. Kept as a guard for callers.
   */
  async write8() {
    this._writeAttemptBlocked += 1;
    throw new Error(
      "MemoryReader is read-only (Fase 0.3 rule). Write attempts are blocked."
    );
  }

  get blockedWriteAttempts() {
    return this._writeAttemptBlocked;
  }
}
