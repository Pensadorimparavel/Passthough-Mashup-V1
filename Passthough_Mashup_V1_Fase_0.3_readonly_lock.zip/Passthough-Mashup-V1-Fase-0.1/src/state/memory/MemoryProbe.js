/**
 * Passthough Mashup V1 — Fase 0.3
 * Read-only probe helper for future address discovery (e.g. Buu's Fury position).
 *
 * Does NOT invent addresses. Captures snapshots and diffs so a human/experiment
 * can document candidates with evidence.
 */

/**
 * @param {import("./MemoryReader.js").MemoryReader} reader
 */
export class MemoryProbe {
  constructor(reader) {
    this._reader = reader;
  }

  /**
   * Snapshot a contiguous range as a Uint8Array (read-only).
   * @param {number} start
   * @param {number} length
   */
  async snapshot(start, length) {
    return this._reader.readBytes(start >>> 0, length);
  }

  /**
   * Diff two snapshots of equal length.
   * @returns {{ offset: number, address: number, before: number, after: number }[]}
   */
  diff(baseAddress, before, after) {
    if (!before || !after || before.length !== after.length) {
      throw new Error("MemoryProbe.diff requires equal-length snapshots");
    }
    const changes = [];
    for (let i = 0; i < before.length; i++) {
      if (before[i] !== after[i]) {
        changes.push({
          offset: i,
          address: (baseAddress + i) >>> 0,
          before: before[i],
          after: after[i]
        });
      }
    }
    return changes;
  }

  /**
   * Convenience: snapshot → caller moves character → snapshot → diff.
   * Returns structured report without claiming any address is "the position".
   */
  reportCandidates(baseAddress, before, after, label = "") {
    const changes = this.diff(baseAddress, before, after);
    return {
      label,
      baseAddress: baseAddress >>> 0,
      changeCount: changes.length,
      changes: changes.slice(0, 256), // cap for log size
      truncated: changes.length > 256,
      note:
        "Candidates only. Promote an address only after multi-axis, multi-area confirmation."
    };
  }
}
