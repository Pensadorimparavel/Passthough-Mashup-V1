/**
 * Passthough Mashup V1 — Fase 0.3
 * Dragon Ball Z: Buu's Fury (USA) state adapter — READ ONLY.
 *
 * Evidence source: Data Crystal RAM map (datacrystal.tcrf.net).
 *
 * Documented with confidence:
 *   - Current character, Goku HP/EP/stats, inventory-related IWRAM
 *
 * NOT documented in public RAM map (as of research for this phase):
 *   - World/screen X/Y position of the active character
 *   - Facing direction / animation frame for overworld movement
 *
 * Those remain CONFIDENCE.NONE until live probe experiments identify them.
 * This adapter will NOT invent or hardcode position addresses.
 */

import { createEmptyGameState, CONFIDENCE } from "../schemas/GameStateSchema.js";
import { regionOf } from "../memory/MemoryReader.js";

/** Data Crystal / cheat-verified IWRAM addresses (Buu's Fury USA). */
export const BUU_ADDR = Object.freeze({
  currentChar: 0x03001068, // 0=Goku … 8=Videl
  gokuHp: 0x03001576, // u16
  gokuMaxHp: 0x03001578, // u16
  gokuEp: 0x0300157a, // u16
  gokuMaxEp: 0x0300157c, // u16
  gokuSpeedStat: 0x0300158b, // u8 (character stat, not world velocity)
  zennie: 0x0300155c // u32
});

const CHAR_NAMES = [
  "Goku",
  "Gohan",
  "Goten",
  "Trunks",
  "Vegeta",
  "Gotenks",
  "Vegito",
  "Gogeta",
  "Videl"
];

/**
 * Documented candidates. Position-related entries are intentionally absent
 * because no public, verified address was found.
 */
export const BUU_CANDIDATES = Object.freeze([
  {
    name: "current_character",
    address: BUU_ADDR.currentChar,
    region: "IWRAM",
    size: 1,
    type: "u8",
    meaning: "Active party character index (0=Goku … 8=Videl)",
    evidence: "Data Crystal RAM map IWRAM 03001068",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "goku_current_hp",
    address: BUU_ADDR.gokuHp,
    region: "IWRAM",
    size: 2,
    type: "u16",
    meaning: "Goku current HP",
    evidence: "Data Crystal RAM map + matching CodeBreaker codes 03001576",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "goku_max_hp",
    address: BUU_ADDR.gokuMaxHp,
    region: "IWRAM",
    size: 2,
    type: "u16",
    meaning: "Goku max HP",
    evidence: "Data Crystal RAM map 03001578",
    confidence: CONFIDENCE.HIGH
  },
  {
    name: "goku_speed_stat",
    address: BUU_ADDR.gokuSpeedStat,
    region: "IWRAM",
    size: 1,
    type: "u8",
    meaning: "Goku Speed stat (RPG attribute, NOT world velocity)",
    evidence: "Data Crystal RAM map 0300158B",
    confidence: CONFIDENCE.HIGH
  }
]);

/**
 * Explicit gaps — documented so they are not filled with invented data.
 */
export const BUU_UNIDENTIFIED = Object.freeze([
  {
    name: "player_world_x",
    meaning: "Active character X in world or screen space",
    status: "not_found_in_public_ram_map",
    confidence: CONFIDENCE.NONE,
    nextStep:
      "Live probe: freeze memory while moving horizontally; diff IWRAM/EWRAM scans"
  },
  {
    name: "player_world_y",
    meaning: "Active character Y in world or screen space",
    status: "not_found_in_public_ram_map",
    confidence: CONFIDENCE.NONE,
    nextStep:
      "Live probe: freeze memory while moving vertically; diff against X candidates"
  },
  {
    name: "facing_direction",
    meaning: "Overworld facing / animation direction",
    status: "not_found_in_public_ram_map",
    confidence: CONFIDENCE.NONE
  },
  {
    name: "world_velocity",
    meaning: "Movement speed in pixels/frame",
    status: "not_found_in_public_ram_map",
    confidence: CONFIDENCE.NONE
  }
]);

export class BuuFuryStateAdapter {
  /**
   * @param {import("../memory/MemoryReader.js").MemoryReader} reader
   */
  constructor(reader) {
    this._reader = reader;
  }

  getCandidates() {
    return BUU_CANDIDATES;
  }

  getUnidentified() {
    return BUU_UNIDENTIFIED;
  }

  /**
   * Snapshot documented Buu's Fury state. Position fields stay null.
   * @returns {Promise<object>}
   */
  async readState() {
    const state = createEmptyGameState("buus_fury");
    const r = this._reader;

    try {
      const charId = await r.read8(BUU_ADDR.currentChar);
      const hp = await r.read16(BUU_ADDR.gokuHp);
      const maxHp = await r.read16(BUU_ADDR.gokuMaxHp);
      const ep = await r.read16(BUU_ADDR.gokuEp);
      const speedStat = await r.read8(BUU_ADDR.gokuSpeedStat);

      state.currentCharacter = CHAR_NAMES[charId] || `id_${charId}`;
      state.hp = hp;
      state.maxHp = maxHp;
      state.speed = null; // must not confuse RPG stat with world velocity
      state.combat = {
        ep,
        gokuSpeedStat: speedStat
      };

      // Explicit: position unknown
      state.position = { x: null, y: null };
      state.direction = null;
      state.animationState = null;
      state.movementState = null;
      state.mapId = null;
      state.camera = { x: null, y: null };

      state.raw = {
        currentCharId: charId,
        gokuHp: hp,
        gokuMaxHp: maxHp,
        gokuEp: ep,
        gokuSpeedStat: speedStat,
        region: regionOf(BUU_ADDR.currentChar)
      };

      state.confidence = {
        position: CONFIDENCE.NONE,
        direction: CONFIDENCE.NONE,
        animationState: CONFIDENCE.NONE,
        movementState: CONFIDENCE.NONE,
        mapId: CONFIDENCE.NONE,
        camera: CONFIDENCE.NONE,
        speed: CONFIDENCE.NONE,
        hp: CONFIDENCE.HIGH,
        currentCharacter: CONFIDENCE.HIGH,
        combat: CONFIDENCE.MEDIUM
      };

      state.notes.push(
        "Position/direction/animation for Buu's Fury are NOT identified in public RAM maps. Fields left null per Fase 0.3 rules."
      );
      state.notes.push(
        "Goku Speed at 0x0300158B is an RPG attribute, not world movement velocity."
      );
    } catch (err) {
      state.notes.push(
        `Read failed: ${err instanceof Error ? err.message : String(err)}`
      );
    }

    state.timestamp = Date.now();
    return state;
  }
}
