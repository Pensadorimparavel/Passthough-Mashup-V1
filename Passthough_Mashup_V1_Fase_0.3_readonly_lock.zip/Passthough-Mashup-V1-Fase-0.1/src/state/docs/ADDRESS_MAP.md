# Fase 0.3 — Mapa de endereços e evidências

## Regra

Nenhum endereço foi inventado. Somente fontes públicas verificáveis (decompilação, Data Crystal, códigos de cheat que batem com o RAM map).

---

## The Minish Cap (Worker A / Host)

**Fonte principal:** [zeldaret/tmc](https://github.com/zeldaret/tmc) — decompilação USA/EU/JP.

| Nome | Endereço | Região | Tipo | Significado | Confiança | Evidência |
|------|----------|--------|------|-------------|-----------|-----------|
| `gPlayerEntity` base | `0x03001160` | IWRAM | struct | Entidade do Link | **alta** | linker.ld / DeepWiki zeldaret |
| Link X (pixel) | `0x0300118E` | IWRAM | s16 | `Entity.x.HALF.HI` | **alta** | `entity.h`: x @ +0x2C Q16.16 → HI @ +0x2E |
| Link Y (pixel) | `0x03001192` | IWRAM | s16 | `Entity.y.HALF.HI` | **alta** | `entity.h`: y @ +0x30 → HI @ +0x32 |
| animationState | `0x03001174` | IWRAM | u8 | Facing idle (0/2/4/6) | **alta** | `entity.h` +0x14 |
| direction | `0x03001175` | IWRAM | u8 | Direção 8 vias | **alta** | `entity.h` +0x15 |
| speed | `0x03001184` | IWRAM | s16 | Magnitude de velocidade | **alta** | `entity.h` +0x24 |
| `gRoomControls` | `0x03000BF0` | IWRAM | struct | Câmera / sala | **média** | símbolo linker; layout de campos ainda parcial |

### Observações Minish Cap

- Coordenadas são **mundo do jogo** em pixels (Q16.16 truncado no HALF.HI), não necessariamente coordenadas de tela.
- Valores só são significativos com o jogo em gameplay ativo (não title screen / file select).
- `mapId` / campos internos de `gRoomControls` (scroll, area, room) ainda não foram mapeados campo a campo nesta fase → `confidence: none` para mapId/camera detalhada.

---

## Dragon Ball Z: Buu's Fury (Worker B / Guest)

**Fonte principal:** [Data Crystal RAM map](https://datacrystal.tcrf.net/wiki/Dragon_Ball_Z:_Buu%27s_Fury/RAM_map) + códigos CodeBreaker que confirmam os mesmos offsets.

| Nome | Endereço | Região | Tipo | Significado | Confiança | Evidência |
|------|----------|--------|------|-------------|-----------|-----------|
| current character | `0x03001068` | IWRAM | u8 | 0=Goku … 8=Videl | **alta** | Data Crystal |
| Goku HP | `0x03001576` | IWRAM | u16 | HP atual | **alta** | Data Crystal + CB `03001576` |
| Goku Max HP | `0x03001578` | IWRAM | u16 | HP máximo | **alta** | Data Crystal |
| Goku EP | `0x0300157A` | IWRAM | u16 | Energy Points | **alta** | Data Crystal |
| Goku Speed **stat** | `0x0300158B` | IWRAM | u8 | Atributo RPG (não velocidade de mundo) | **alta** | Data Crystal |

### Não identificados (obrigatório declarar)

| Nome | Status | Próximo passo |
|------|--------|---------------|
| Posição X/Y do personagem ativo | **não encontrado** em RAM map público | Probe ao vivo: mover horizontal/vertical e diff de IWRAM/EWRAM |
| Direção / animação de overworld | **não encontrado** | Correlacionar com mudanças de sprite/OAM |
| Velocidade de movimento no mundo | **não encontrado** | Não confundir com Speed stat RPG |

**Consequência:** o adaptador de Buu's Fury deixa `position`, `direction`, `animationState` e `movementState` como `null` com `confidence: none`. A Fase 0.3 **não declara** essas variáveis como resolvidas.

---

## Metodologia de probe (para completar Buu's Fury)

1. Carregar ROM no Worker B, avançar até overworld controlável.
2. Snapshot IWRAM (`0x03000000`–`0x03007FFF`) parado.
3. Mover só no eixo X por N frames; novo snapshot; diff.
4. Repetir no eixo Y.
5. Candidatos que mudam monotonicamente com o eixo são prioritários.
6. Confirmar estabilidade em múltiplas áreas antes de promover a `medium`/`high`.

A página `tests/phase0_3.html` inclui um modo de amostragem para auxiliar esse processo (somente leitura).
