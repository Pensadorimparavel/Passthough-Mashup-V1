# Passthough Mashup V1 — Fase 0.1

Preparação experimental do núcleo **mGBA C** para WebAssembly. Esta entrega é um scaffold técnico inicial, não uma build validada.

## Estado honesto desta entrega

- A camada C usa a API pública `struct mCore` do mGBA: `GBACoreCreate`, `init/deinit`, `loadROM/unloadROM`, `runFrame`, `setKeys`, `busRead8/busWrite8`, `frameCounter` e `setVideoBuffer`.
- O código do mGBA **não é copiado** para este pacote. O script baixa o repositório oficial para `external/mgba`.
- O build foi preparado para gerar um módulo Emscripten modularizado (`.mjs`) que será instanciado separadamente dentro de cada Dedicated Web Worker.
- Não há Pthreads, `SharedArrayBuffer`, EmulatorJS, substituição de sprites ou integração visual nesta fase.
- **Não foi possível compilar nem executar o WebAssembly neste ambiente**: `emcc` não está instalado. Portanto, os testes A–G ainda não foram executados contra o núcleo real. Não há resultados de desempenho reportáveis.

## Estrutura

```text
Passthough-Mashup-V1/
├── src/
│   ├── core/
│   │   ├── mgba_wrapper.c
│   │   └── mgba_wrapper.h
│   ├── bridge/
│   │   ├── MessageProtocol.js
│   │   └── Bridge.js
│   └── workers/
│       └── emulator.worker.js
├── tests/
│   ├── phase0_1.html
│   ├── phase0_1.js
│   ├── phase0_2_1.html
│   └── phase0_2_1.js
├── scripts/
│   ├── prepare_mgba.sh
│   └── build_wasm.sh
├── CMakeLists.txt
├── .gitignore
└── README.md
```

## Dependências

1. Git
2. CMake 3.20+
3. Python 3 (para servir os arquivos estáticos)
4. Emscripten SDK instalado e ativado (`emcc`, `emcmake`, `emmake`)

A documentação oficial do mGBA recomenda CMake e mantém o código-fonte em `https://github.com/mgba-emu/mgba`. Este projeto usa o CMake upstream em modo `LIBMGBA_ONLY`, evitando compilar os frontends desktop.

## Preparar o código-fonte

Na raiz do projeto:

```bash
bash scripts/prepare_mgba.sh
```

O script clona a branch `master` oficial em `external/mgba` e aplica uma pequena alteração local no CMake upstream para que a detecção POSIX não ative a infraestrutura de pthreads durante o build WebAssembly. O patch é restrito ao build local e é descrito no script.

> Para uma build reprodutível, a próxima revisão deverá fixar o clone em um commit específico. Esta primeira entrega acompanha a branch upstream atual e não fixa ainda um hash.

## Compilar

Ative o Emscripten SDK no terminal e execute:

```bash
bash scripts/build_wasm.sh
```

Saídas esperadas após uma compilação bem-sucedida:

```text
wasm/mgba_wasm.mjs
wasm/mgba_wasm.wasm
```

Se a compilação falhar, preserve o log completo. Não considere a Fase 0.1 aprovada até corrigir a falha e executar os testes no navegador.

## Executar a página de testes

Depois de compilar:

```bash
python3 -m http.server 8000
```

Abra no navegador:

```text
http://localhost:8000/tests/phase0_1.html
```

Para Android, o servidor deve estar acessível na rede local e o navegador do telefone deve abrir o endereço do computador. Nesta etapa o teste foi pensado para navegador moderno com suporte a WebAssembly e módulos ES.

Selecione uma ROM GBA legítima que você tenha direito de usar. A mesma ROM pode ser selecionada nos dois campos. Nenhuma ROM é incluída no projeto.

## O que a página mede/verifica

- A: inicialização de cada worker e criação de cada módulo mGBA.
- B: carregamento da ROM selecionada em cada instância.
- C: avanço de exatamente um frame por chamada.
- D: envio de máscara de teclas e leitura/escrita de memória EWRAM.
- E: dimensões e tamanho do framebuffer.
- F/G: dois Dedicated Workers com instâncias WASM separadas; a página grava sentinelas diferentes na EWRAM e verifica que uma instância não altera a memória da outra.
- Desempenho: tempo total e média por frame para o lote executado. A memória reportada é o tamanho da memória linear WebAssembly alocada, não uma medição de RSS do processo.

A verificação de isolamento não compara apenas contadores. Ela grava valores distintos em endereços equivalentes de EWRAM nos dois workers e confirma que cada valor permanece independente.

## Limitações conhecidas

- O build ainda precisa ser validado com uma versão concreta do Emscripten e um commit fixo do mGBA.
- A página de testes requer ROM GBA fornecida pelo usuário; não há ROM sintética apresentada como jogo válido.
- O framebuffer é exposto no formato nativo `mColor` do mGBA (build de 32 bits, `mCOLOR_XBGR8`). Esta fase verifica dimensões e bytes, mas ainda não faz conversão para Canvas/RGBA.
- O mGBA usa `busRead8/busWrite8` para acesso ao barramento. A interpretação de endereços de memória será específica da plataforma GBA.
- Não há áudio, save persistence, BIOS real, interface de jogo ou sincronização Host/Guest.
- Duas instâncias em dois workers demonstram isolamento do contexto WASM, mas o consumo/performance em Android só pode ser concluído após testes no aparelho-alvo.

## Critério de aprovação

Não avançar para Dual Probe nem para integração de jogos até:
1. compilar o núcleo mGBA + wrapper com Emscripten;
2. executar A–G com uma ROM GBA real;
3. confirmar dois workers e duas memórias lineares independentes;
4. registrar tempos e tamanho de memória observados;
5. testar estabilidade em Android.

## Fase 0.2.1 — Bridge independente

Comunicação bidirecional entre os dois Dedicated Workers, mediada exclusivamente pela thread principal.

### Novos arquivos

```text
src/bridge/
├── MessageProtocol.js   # envelope, validação, tipos permitidos
└── Bridge.js            # roteamento, origem real, rejeições
tests/
├── phase0_2_1.html
└── phase0_2_1.js
```

### Modificação mínima

`src/workers/emulator.worker.js` — adicionados apenas os canais `bridge` e `bridgeEmit`. Todos os comandos da Fase 0.1 permanecem intactos.

### Protocolo

Envelope:

- `protocolVersion` (atual = 1)
- `messageId`
- `origin` / `destination` (`"A"` | `"B"`)
- `type` (permitidos nesta fase: `ping`, `pong`, `echo`, `ack`, `test`, `status`)
- `timestamp`
- `payload`
- `correlationId` (opcional)

A origem real é determinada pela instância do Worker que postou a mensagem, não apenas pelo campo `origin` do envelope. Mensagens com destino inexistente, self-destination, versão errada ou tipo não permitido são rejeitadas.

### Como executar os testes da Bridge

1. Compile o WASM (se ainda não estiver em `wasm/`):
   ```bash
   bash scripts/build_wasm.sh
   ```
2. Sirva a pasta:
   ```bash
   python3 -m http.server 8000
   ```
3. Abra:
   ```text
   http://localhost:8000/tests/phase0_2_1.html
   ```
4. Selecione ROMs GBA legítimas e clique em **Executar testes T1–T8 + regressão Fase 0.1**.

### Escopo explícito desta fase

Implementado:

- Bridge na thread principal
- Comunicação A ↔ B
- Validação de protocolo e payloads
- Testes automatizados T1–T8 + regressão da Fase 0.1

Não implementado (propositadamente):

- Leitura de memória para integração de jogos
- Transferência de movimentos / estados
- Controle de personagem de um jogo pelo outro
- Integração de gameplay
- Alterações no wrapper C / CMake / scripts de build

## Licença

O wrapper deste projeto é código experimental próprio. O mGBA é um projeto separado licenciado sob MPL-2.0; ao clonar/buildar o upstream, consulte e preserve os avisos e termos de licença do repositório oficial.
