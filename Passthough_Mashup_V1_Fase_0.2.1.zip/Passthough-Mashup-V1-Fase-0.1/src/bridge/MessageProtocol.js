/**
 * Passthough Mashup V1 — Fase 0.2.1
 * MessageProtocol: envelope definition, validation and helpers for the Bridge.
 *
 * This protocol is completely separate from the emulator command protocol
 * (init, loadRom, runFrame, setKeys, etc.).
 */

export const PROTOCOL_VERSION = 1;

export const WORKER_IDS = Object.freeze(["A", "B"]);

/** Message types allowed in Phase 0.2.1 (no gameplay / memory integration). */
export const ALLOWED_TYPES = Object.freeze([
  "ping",
  "pong",
  "echo",
  "ack",
  "test",
  "status"
]);

/**
 * Create a well-formed bridge envelope.
 * @param {object} options
 * @param {"A"|"B"} options.origin
 * @param {"A"|"B"} options.destination
 * @param {string} options.type
 * @param {unknown} [options.payload]
 * @param {string} [options.correlationId]
 * @param {string} [options.messageId] - if omitted a unique id is generated
 * @returns {object}
 */
export function createEnvelope({
  origin,
  destination,
  type,
  payload = null,
  correlationId = undefined,
  messageId = undefined
}) {
  const envelope = {
    protocolVersion: PROTOCOL_VERSION,
    messageId: messageId || generateMessageId(),
    origin,
    destination,
    type,
    timestamp: Date.now(),
    payload
  };
  if (correlationId !== undefined) {
    envelope.correlationId = correlationId;
  }
  return envelope;
}

/**
 * Generate a reasonably unique message id.
 * @returns {string}
 */
export function generateMessageId() {
  return `msg_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 10)}`;
}

/**
 * Validate an envelope.
 * Returns { valid: true } or { valid: false, reason: string }.
 * Does NOT check the real Worker origin (that is the responsibility of the Bridge).
 *
 * @param {unknown} envelope
 * @returns {{ valid: true } | { valid: false, reason: string }}
 */
export function validateEnvelope(envelope) {
  if (envelope === null || typeof envelope !== "object" || Array.isArray(envelope)) {
    return { valid: false, reason: "Envelope must be a non-null object" };
  }

  if (envelope.protocolVersion !== PROTOCOL_VERSION) {
    return {
      valid: false,
      reason: `Unsupported protocolVersion: ${String(envelope.protocolVersion)} (expected ${PROTOCOL_VERSION})`
    };
  }

  if (typeof envelope.messageId !== "string" || envelope.messageId.length === 0) {
    return { valid: false, reason: "messageId must be a non-empty string" };
  }

  if (!WORKER_IDS.includes(envelope.origin)) {
    return {
      valid: false,
      reason: `Invalid origin: ${String(envelope.origin)} (allowed: ${WORKER_IDS.join(", ")})`
    };
  }

  if (!WORKER_IDS.includes(envelope.destination)) {
    return {
      valid: false,
      reason: `Invalid destination: ${String(envelope.destination)} (allowed: ${WORKER_IDS.join(", ")})`
    };
  }

  if (envelope.origin === envelope.destination) {
    return {
      valid: false,
      reason: "origin and destination must be different (self-destination rejected)"
    };
  }

  if (typeof envelope.type !== "string" || !ALLOWED_TYPES.includes(envelope.type)) {
    return {
      valid: false,
      reason: `Invalid or disallowed type: ${String(envelope.type)} (allowed: ${ALLOWED_TYPES.join(", ")})`
    };
  }

  if (typeof envelope.timestamp !== "number" || !Number.isFinite(envelope.timestamp)) {
    return { valid: false, reason: "timestamp must be a finite number" };
  }

  // payload may be any JSON-serializable value (including null)
  if (envelope.correlationId !== undefined && typeof envelope.correlationId !== "string") {
    return { valid: false, reason: "correlationId, when present, must be a string" };
  }

  return { valid: true };
}

/**
 * Quick check whether a value looks like a bridge envelope (for routing decisions).
 * @param {unknown} value
 * @returns {boolean}
 */
export function isBridgeEnvelope(value) {
  return (
    value !== null &&
    typeof value === "object" &&
    !Array.isArray(value) &&
    "protocolVersion" in value &&
    "messageId" in value &&
    "origin" in value &&
    "destination" in value &&
    "type" in value
  );
}
