/**
 * Passthough Mashup V1 — Fase 0.2.1
 * Bridge: main-thread intermediary for bidirectional communication
 * between Worker A and Worker B.
 *
 * - Does NOT talk to the mGBA core.
 * - Does NOT use SharedArrayBuffer / Atomics / Pthreads.
 * - Origin is determined by the real Worker instance that posted the message,
 *   not solely by the envelope.origin field.
 */

import {
  PROTOCOL_VERSION,
  WORKER_IDS,
  createEnvelope,
  validateEnvelope,
  generateMessageId
} from "./MessageProtocol.js";

/**
 * @typedef {"A"|"B"} WorkerId
 */

/**
 * Minimal interface expected from a worker wrapper:
 * - raw: the underlying Worker
 * - request(type, payload?, transfer?): Promise
 * - postBridge?(envelope): void   (optional helper)
 */
export class Bridge {
  /**
   * @param {object} workerA - wrapper with .raw (Worker)
   * @param {object} workerB - wrapper with .raw (Worker)
   * @param {object} [options]
   * @param {(event: object) => void} [options.onLog]
   * @param {(event: object) => void} [options.onMessage]
   * @param {(event: object) => void} [options.onReject]
   */
  constructor(workerA, workerB, options = {}) {
    this._workers = {
      A: workerA,
      B: workerB
    };
    this._onLog = options.onLog || (() => {});
    this._onMessage = options.onMessage || (() => {});
    this._onReject = options.onReject || (() => {});

    /** @type {Map<string, object>} recent messageIds for basic duplicate detection */
    this._recentIds = new Map();
    this._maxRecent = 2000;

    /** @type {Map<string, {resolve: Function, reject: Function, timeout: any}>} */
    this._pending = new Map();

    this._boundHandlers = {
      A: (event) => this._handleWorkerMessage("A", event),
      B: (event) => this._handleWorkerMessage("B", event)
    };

    this._attach();
  }

  _attach() {
    for (const id of WORKER_IDS) {
      const w = this._workers[id];
      if (!w || !w.raw) {
        throw new Error(`Bridge: worker ${id} is missing or has no .raw Worker`);
      }
      w.raw.addEventListener("message", this._boundHandlers[id]);
    }
  }

  /**
   * Detach listeners. Call when the Bridge is no longer needed.
   */
  destroy() {
    for (const id of WORKER_IDS) {
      const w = this._workers[id];
      if (w && w.raw) {
        w.raw.removeEventListener("message", this._boundHandlers[id]);
      }
    }
    for (const [, entry] of this._pending) {
      clearTimeout(entry.timeout);
      entry.reject(new Error("Bridge destroyed"));
    }
    this._pending.clear();
    this._recentIds.clear();
  }

  /**
   * Send a bridge message from one worker identity to the other.
   * The Bridge constructs a valid envelope and posts it to the destination Worker.
   *
   * @param {WorkerId} origin
   * @param {WorkerId} destination
   * @param {string} type
   * @param {unknown} [payload]
   * @param {object} [opts]
   * @param {string} [opts.correlationId]
   * @param {number} [opts.timeoutMs=5000]
   * @returns {Promise<object>} resolves with the response envelope (or ack) from the destination
   */
  send(origin, destination, type, payload = null, opts = {}) {
    if (!WORKER_IDS.includes(origin) || !WORKER_IDS.includes(destination)) {
      return Promise.reject(new Error("Bridge.send: invalid origin or destination"));
    }
    if (origin === destination) {
      return Promise.reject(new Error("Bridge.send: origin and destination must differ"));
    }

    const envelope = createEnvelope({
      origin,
      destination,
      type,
      payload,
      correlationId: opts.correlationId
    });

    const validation = validateEnvelope(envelope);
    if (!validation.valid) {
      this._onReject({ reason: validation.reason, envelope, source: "Bridge.send" });
      return Promise.reject(new Error(validation.reason));
    }

    return this._deliver(envelope, opts.timeoutMs ?? 5000);
  }

  /**
   * Internal: post the envelope to the destination Worker and wait for a response.
   * @param {object} envelope
   * @param {number} timeoutMs
   * @returns {Promise<object>}
   */
  _deliver(envelope, timeoutMs) {
    const dest = envelope.destination;
    const worker = this._workers[dest];
    if (!worker || !worker.raw) {
      return Promise.reject(new Error(`Bridge: destination Worker ${dest} not available`));
    }

    const responseId = envelope.messageId;

    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        this._pending.delete(responseId);
        reject(new Error(`Bridge timeout waiting for response to ${responseId}`));
      }, timeoutMs);

      this._pending.set(responseId, { resolve, reject, timeout });

      this._onLog({
        direction: "out",
        from: envelope.origin,
        to: dest,
        type: envelope.type,
        messageId: envelope.messageId
      });

      // Post to the destination Worker using the dedicated bridge channel.
      worker.raw.postMessage({
        type: "bridge",
        envelope
      });
    });
  }

  /**
   * Handle any message coming from a real Worker.
   * Distinguishes normal emulator replies from bridgeOut messages.
   * @param {WorkerId} realOrigin - the Worker that actually posted the message
   * @param {MessageEvent} event
   */
  _handleWorkerMessage(realOrigin, event) {
    const data = event.data;
    if (!data || typeof data !== "object") return;

    // Dedicated bridge channel from Worker → Main
    if (data.type === "bridgeOut") {
      this._handleBridgeOut(realOrigin, data.envelope);
      return;
    }

    // Responses to a bridge delivery (Worker processed an incoming "bridge" message)
    if (data.type === "bridgeResponse") {
      this._handleBridgeResponse(realOrigin, data);
      return;
    }

    // Everything else belongs to the existing emulator request/response protocol.
    // The Bridge ignores it so it does not interfere with Phase 0.1 commands.
  }

  /**
   * A Worker is voluntarily emitting a bridge message.
   * Real origin is forced to the Worker that posted it.
   * @param {WorkerId} realOrigin
   * @param {object} envelope
   */
  _handleBridgeOut(realOrigin, envelope) {
    if (!envelope || typeof envelope !== "object") {
      this._onReject({
        reason: "bridgeOut without a valid envelope object",
        source: realOrigin
      });
      return;
    }

    // Force the real origin. The Worker cannot claim to be the other side.
    const corrected = {
      ...envelope,
      origin: realOrigin,
      protocolVersion: envelope.protocolVersion ?? PROTOCOL_VERSION,
      messageId: envelope.messageId || generateMessageId(),
      timestamp: envelope.timestamp ?? Date.now()
    };

    const validation = validateEnvelope(corrected);
    if (!validation.valid) {
      this._onReject({
        reason: validation.reason,
        envelope: corrected,
        source: realOrigin
      });
      // Optionally notify the sender
      this._postRejectToWorker(realOrigin, corrected, validation.reason);
      return;
    }

    // Duplicate detection (best-effort)
    if (this._recentIds.has(corrected.messageId)) {
      this._onReject({
        reason: `Duplicate messageId: ${corrected.messageId}`,
        envelope: corrected,
        source: realOrigin
      });
      return;
    }
    this._rememberId(corrected.messageId);

    this._onLog({
      direction: "in",
      from: realOrigin,
      to: corrected.destination,
      type: corrected.type,
      messageId: corrected.messageId
    });

    this._onMessage({
      envelope: corrected,
      realOrigin
    });

    // Forward to the other Worker
    this._deliver(corrected, 5000).catch((err) => {
      this._onReject({
        reason: err.message,
        envelope: corrected,
        source: "forward"
      });
    });
  }

  /**
   * Handle a response that a Worker produced after receiving a "bridge" message.
   * @param {WorkerId} realOrigin
   * @param {object} data
   */
  _handleBridgeResponse(realOrigin, data) {
    const envelope = data.envelope;
    const inReplyTo = data.inReplyTo || (envelope && envelope.correlationId) || (envelope && envelope.messageId);

    if (!inReplyTo) {
      this._onReject({
        reason: "bridgeResponse missing inReplyTo / correlation",
        source: realOrigin,
        data
      });
      return;
    }

    const pending = this._pending.get(inReplyTo);
    if (!pending) {
      // Late or unknown response — ignore quietly after logging
      this._onLog({
        direction: "late-or-unknown-response",
        from: realOrigin,
        inReplyTo
      });
      return;
    }

    clearTimeout(pending.timeout);
    this._pending.delete(inReplyTo);

    // Ensure the response origin matches the Worker that replied
    const responseEnvelope = {
      ...(envelope || {}),
      origin: realOrigin,
      protocolVersion: (envelope && envelope.protocolVersion) || PROTOCOL_VERSION,
      messageId: (envelope && envelope.messageId) || generateMessageId(),
      timestamp: (envelope && envelope.timestamp) || Date.now(),
      correlationId: inReplyTo
    };

    this._onLog({
      direction: "response",
      from: realOrigin,
      inReplyTo,
      type: responseEnvelope.type
    });

    this._onMessage({
      envelope: responseEnvelope,
      realOrigin,
      isResponse: true
    });

    pending.resolve(responseEnvelope);
  }

  _postRejectToWorker(workerId, originalEnvelope, reason) {
    const w = this._workers[workerId];
    if (!w || !w.raw) return;
    try {
      w.raw.postMessage({
        type: "bridge",
        envelope: createEnvelope({
          origin: workerId === "A" ? "B" : "A", // synthetic
          destination: workerId,
          type: "ack",
          payload: { error: true, reason, originalMessageId: originalEnvelope.messageId }
        })
      });
    } catch (_) {
      // ignore
    }
  }

  _rememberId(id) {
    this._recentIds.set(id, Date.now());
    if (this._recentIds.size > this._maxRecent) {
      // drop oldest
      const first = this._recentIds.keys().next().value;
      this._recentIds.delete(first);
    }
  }
}
