#ifndef PASSTHOUGH_MGBA_WRAPPER_H
#define PASSTHOUGH_MGBA_WRAPPER_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct MGBAInstance MGBAInstance;

MGBAInstance* mgba_create(void);
int mgba_load_rom(MGBAInstance* instance, const uint8_t* data, size_t size);
int mgba_run_frame(MGBAInstance* instance);
void mgba_set_keys(MGBAInstance* instance, uint32_t keys);
uint32_t mgba_get_keys(MGBAInstance* instance);
uint32_t mgba_read_memory8(MGBAInstance* instance, uint32_t address);
int mgba_write_memory8(MGBAInstance* instance, uint32_t address, uint8_t value);
uint32_t mgba_get_frame_counter(MGBAInstance* instance);
uintptr_t mgba_get_framebuffer_ptr(MGBAInstance* instance);
size_t mgba_get_framebuffer_size(MGBAInstance* instance);
unsigned mgba_get_framebuffer_width(MGBAInstance* instance);
unsigned mgba_get_framebuffer_height(MGBAInstance* instance);
void mgba_destroy(MGBAInstance* instance);

#ifdef __cplusplus
}
#endif

#endif
