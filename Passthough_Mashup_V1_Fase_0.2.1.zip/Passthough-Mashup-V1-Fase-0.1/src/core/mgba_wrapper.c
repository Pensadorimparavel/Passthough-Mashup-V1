#include "mgba_wrapper.h"

#include <stdlib.h>
#include <string.h>

#include <mgba/core/core.h>
#include <mgba/gba/core.h>
#include <mgba-util/image.h>
#include <mgba-util/vfs.h>

#ifdef __EMSCRIPTEN__
#include <emscripten/emscripten.h>
#define MGBA_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define MGBA_EXPORT
#endif

#define GBA_SCREEN_WIDTH 240u
#define GBA_SCREEN_HEIGHT 160u

struct MGBAInstance {
    struct mCore* core;
    uint8_t* rom_copy;
    mColor* framebuffer;
    size_t framebuffer_bytes;
    int rom_loaded;
};

static void mgba_release_rom(MGBAInstance* instance) {
    if (!instance) return;

    if (instance->core && instance->rom_loaded) {
        /* mGBA's GBA core owns and closes the VFile passed to loadROM(). */
        instance->core->unloadROM(instance->core);
        instance->rom_loaded = 0;
    }

    free(instance->rom_copy);
    instance->rom_copy = NULL;
}

MGBA_EXPORT MGBAInstance* mgba_create(void) {
    MGBAInstance* instance = (MGBAInstance*) calloc(1, sizeof(*instance));
    if (!instance) return NULL;

    instance->core = GBACoreCreate();
    if (!instance->core) {
        free(instance);
        return NULL;
    }

    /* Use mGBA's HLE BIOS path; no external BIOS file is required for this probe. */
    instance->core->opts.useBios = false;
    instance->core->opts.skipBios = true;
    instance->core->opts.mute = true;

    if (!instance->core->init(instance->core)) {
        instance->core->deinit(instance->core);
        free(instance);
        return NULL;
    }

    instance->framebuffer_bytes =
        (size_t) GBA_SCREEN_WIDTH * (size_t) GBA_SCREEN_HEIGHT * sizeof(mColor);
    instance->framebuffer = (mColor*) calloc(
        (size_t) GBA_SCREEN_WIDTH * (size_t) GBA_SCREEN_HEIGHT,
        sizeof(mColor));

    if (!instance->framebuffer) {
        instance->core->deinit(instance->core);
        free(instance);
        return NULL;
    }

    /* mCore's stride argument is in pixels, not bytes. */
    instance->core->setVideoBuffer(
        instance->core, instance->framebuffer, GBA_SCREEN_WIDTH);

    return instance;
}

MGBA_EXPORT int mgba_load_rom(
    MGBAInstance* instance, const uint8_t* data, size_t size) {
    if (!instance || !instance->core || !data || size < 0xC0) return 0;

    mgba_release_rom(instance);

    instance->rom_copy = (uint8_t*) malloc(size);
    if (!instance->rom_copy) return 0;
    memcpy(instance->rom_copy, data, size);

    /*
     * VFileFromConstMemory refers to the supplied bytes. Keep rom_copy alive
     * for the entire time the core owns this VFile. The GBA core closes the
     * VFile from unloadROM()/deinit().
     */
    struct VFile* rom_vf = VFileFromConstMemory(instance->rom_copy, size);
    if (!rom_vf) {
        free(instance->rom_copy);
        instance->rom_copy = NULL;
        return 0;
    }

    if (!instance->core->loadROM(instance->core, rom_vf)) {
        /* On a failed GBA load, ownership was not retained by the core. */
        rom_vf->close(rom_vf);
        free(instance->rom_copy);
        instance->rom_copy = NULL;
        return 0;
    }

    instance->rom_loaded = 1;
    instance->core->reset(instance->core);
    return 1;
}

MGBA_EXPORT int mgba_run_frame(MGBAInstance* instance) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    instance->core->runFrame(instance->core);
    return 1;
}

MGBA_EXPORT void mgba_set_keys(MGBAInstance* instance, uint32_t keys) {
    if (!instance || !instance->core || !instance->rom_loaded) return;
    /* `keys` is the GBA core's mGBA key bitmask; it is not a browser keycode. */
    instance->core->setKeys(instance->core, keys);
}

MGBA_EXPORT uint32_t mgba_get_keys(MGBAInstance* instance) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    return instance->core->getKeys(instance->core);
}

MGBA_EXPORT uint32_t mgba_read_memory8(
    MGBAInstance* instance, uint32_t address) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    return instance->core->busRead8(instance->core, address) & 0xFFu;
}

MGBA_EXPORT int mgba_write_memory8(
    MGBAInstance* instance, uint32_t address, uint8_t value) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    instance->core->busWrite8(instance->core, address, value);
    return 1;
}

MGBA_EXPORT uint32_t mgba_get_frame_counter(MGBAInstance* instance) {
    if (!instance || !instance->core || !instance->rom_loaded) return 0;
    return instance->core->frameCounter(instance->core);
}

MGBA_EXPORT uintptr_t mgba_get_framebuffer_ptr(MGBAInstance* instance) {
    if (!instance || !instance->framebuffer) return 0;
    return (uintptr_t) instance->framebuffer;
}

MGBA_EXPORT size_t mgba_get_framebuffer_size(MGBAInstance* instance) {
    if (!instance) return 0;
    return instance->framebuffer_bytes;
}

MGBA_EXPORT unsigned mgba_get_framebuffer_width(MGBAInstance* instance) {
    return instance ? GBA_SCREEN_WIDTH : 0;
}

MGBA_EXPORT unsigned mgba_get_framebuffer_height(MGBAInstance* instance) {
    return instance ? GBA_SCREEN_HEIGHT : 0;
}

MGBA_EXPORT void mgba_destroy(MGBAInstance* instance) {
    if (!instance) return;

    mgba_release_rom(instance);

    if (instance->core) {
        /* deinit() frees the mCore allocation itself in the upstream GBA core. */
        instance->core->deinit(instance->core);
        instance->core = NULL;
    }

    free(instance->framebuffer);
    instance->framebuffer = NULL;
    free(instance->rom_copy);
    instance->rom_copy = NULL;
    free(instance);
}
