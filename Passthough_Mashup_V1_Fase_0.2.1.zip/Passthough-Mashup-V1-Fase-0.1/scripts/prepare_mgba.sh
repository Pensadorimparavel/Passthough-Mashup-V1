#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MGBA_DIR="$ROOT/external/mgba"

if ! command -v git >/dev/null 2>&1; then
  echo "ERRO: Git não encontrado." >&2
  exit 1
fi

mkdir -p "$ROOT/external"
if [ ! -d "$MGBA_DIR/.git" ]; then
  git clone --depth 1 https://github.com/mgba-emu/mgba.git "$MGBA_DIR"
else
  echo "mGBA já existe em external/mgba; mantendo a cópia local."
fi

python3 - "$MGBA_DIR/CMakeLists.txt" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text()
old = "set(USE_PTHREADS ON)"
new = "if(NOT EMSCRIPTEN)\n\tset(USE_PTHREADS ON)\nendif()"

if new in text:
    print("Patch de pthreads já aplicado.")
elif old in text:
    path.write_text(text.replace(old, new, 1))
    print("Patch aplicado: desativa a ativação automática de pthreads em builds Emscripten.")
else:
    raise SystemExit(
        "ERRO: não encontrei a linha esperada de detecção USE_PTHREADS no CMake upstream. "
        "A versão do mGBA mudou; revise o CMakeLists.txt antes de compilar."
    )
PY

echo "mGBA preparado em: $MGBA_DIR"
echo "Revisão upstream atual:"
git -C "$MGBA_DIR" rev-parse HEAD
