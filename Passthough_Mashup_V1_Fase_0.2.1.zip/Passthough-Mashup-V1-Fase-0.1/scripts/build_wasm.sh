#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

for tool in emcc emcmake cmake; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    echo "ERRO: '$tool' não encontrado. Instale/ative o Emscripten SDK." >&2
    exit 1
  fi
done

bash scripts/prepare_mgba.sh

emcmake cmake -S . -B build-wasm -DCMAKE_BUILD_TYPE=Release
cmake --build build-wasm --parallel

mkdir -p wasm
echo "Build concluído. Confira os arquivos gerados em wasm/."
