/**
 * Passthough Mashup V1 — Fase 0.2.1
 * Automated tests for the Bridge using the real Workers from Phase 0.1.
 */

import { Bridge } from "../src/bridge/Bridge.js";
import {
  createEnvelope,
  validateEnvelope,
  PROTOCOL_VERSION,
  ALLOWED_TYPES
} from "../src/bridge/MessageProtocol.js";

const logElement = document.querySelector("#log");
const runButton = document.querySelector("#runTests");
const stopButton = document.querySelector("#stopWorkers");
const romAInput = document.querySelector("#romA");
const romBInput = document.querySelector("#romB");

let workers = [];
let bridge = null;
let passed = 0;
let failed = 0;

function log(message, cls = "") {
  const line = document.createElement("div");
  if (cls) line.className = cls;
  line.textContent = message;
  logElement.appendChild(line);
  logElement.scrollTop = logElement.scrollHeight;
}

function assert(condition, message) {
  if (!condition) {
    failed += 1;
    log(`FALHOU: ${message}`, "fail");
    throw new Error(`FALHOU: ${message}`);
  }
  passed += 1;
  log(`OK: ${message}`, "ok");
}

/**
 * Same worker factory used in Phase 0.1, extended with a bridgeEmit helper.
 */
function makeWorker() {
  const worker = new Worker(
    new URL("../src/workers/emulator.worker.js", import.meta.url),
    { type: "module" }
  );
  let nextId = 1;
  const pending = new Map();

  worker.onmessage = (event) => {
    const message = event.data;
    // Ignore bridge channel messages here; the Bridge class listens on the raw Worker.
    if (message && (message.type === "bridgeOut" || message.type === "bridgeResponse")) {
      return;
    }
    const item = pending.get(message.id);
    if (!item) return;
    pending.delete(message.id);
    if (message.ok) item.resolve(message);
    else item.reject(new Error(message.error || "Erro não especificado no worker."));
  };

  worker.onerror = (event) => {
    for (const item of pending.values()) item.reject(new Error(event.message));
    pending.clear();
  };

  return {
    raw: worker,
    request(type, payload = {}, transfer = []) {
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        worker.postMessage({ id, type, ...payload }, transfer);
      });
    },
    terminate() {
      worker.terminate();
      for (const item of pending.values()) item.reject(new Error("Worker encerrado."));
      pending.clear();
    }
  };
}

async function readFile(input, fallback) {
  const file = input.files?.[0] || fallback;
  if (!file) {
    throw new Error(
      "Selecione uma ROM GBA para cada worker (ou selecione apenas A para reutilizá-la em B)."
    );
  }
  return file.arrayBuffer();
}

function stopAll() {
  if (bridge) {
    bridge.destroy();
    bridge = null;
  }
  for (const w of workers) w.terminate();
  workers = [];
}

stopButton.addEventListener("click", () => {
  stopAll();
  log("\nWorkers e Bridge encerrados pelo usuário.");
});

runButton.addEventListener("click", async () => {
  runButton.disabled = true;
  stopAll();
  logElement.textContent = "";
  passed = 0;
  failed = 0;

  try {
    // ----------------------------------------------------------------
    // Bootstrap: real Workers + ROMs (regression of Phase 0.1 init path)
    // ----------------------------------------------------------------
    log("=== Bootstrap (regressão Fase 0.1) ===");
    const romBufferA = await readFile(romAInput);
    const romBufferB = await readFile(romBInput, romAInput.files?.[0]);

    const workerA = makeWorker();
    const workerB = makeWorker();
    workers = [workerA, workerB];

    const [readyA, readyB] = await Promise.all([
      workerA.request("init"),
      workerB.request("init")
    ]);
    assert(readyA.type === "ready", "Worker A inicializou o núcleo mGBA");
    assert(readyB.type === "ready", "Worker B inicializou o núcleo mGBA");
    assert(workerA.raw !== workerB.raw, "Dois Dedicated Workers distintos foram criados");

    await Promise.all([
      workerA.request("loadRom", { rom: romBufferA }, [romBufferA]),
      workerB.request("loadRom", { rom: romBufferB }, [romBufferB])
    ]);
    assert(true, "ROMs carregadas em A e B");

    const [frameA, frameB] = await Promise.all([
      workerA.request("runFrame"),
      workerB.request("runFrame")
    ]);
    assert(
      frameA.frameCounter === frameA.beforeFrameCounter + 1,
      "Worker A avançou exatamente um frame (regressão)"
    );
    assert(
      frameB.frameCounter === frameB.beforeFrameCounter + 1,
      "Worker B avançou exatamente um frame (regressão)"
    );

    // ----------------------------------------------------------------
    // Create Bridge
    // ----------------------------------------------------------------
    log("\n=== Criando Bridge ===");
    const rejects = [];
    const received = [];

    bridge = new Bridge(workerA, workerB, {
      onLog: (ev) => {
        // silent for volume tests; can be enabled for debugging
      },
      onMessage: (ev) => {
        received.push(ev);
      },
      onReject: (ev) => {
        rejects.push(ev);
      }
    });
    assert(true, "Bridge instanciada na thread principal");

    // ----------------------------------------------------------------
    // T1: A → B
    // ----------------------------------------------------------------
    log("\n=== T1: A → B ===");
    const t1 = await bridge.send("A", "B", "ping", { seq: 1, from: "A" });
    assert(t1.type === "pong", "T1: B respondeu com pong");
    assert(t1.origin === "B", "T1: origem real da resposta é B");
    assert(t1.destination === "A", "T1: destino da resposta é A");
    assert(t1.payload && t1.payload.pong === true, "T1: payload pong correto");
    assert(
      t1.payload.echo && t1.payload.echo.seq === 1,
      "T1: payload original ecoado corretamente"
    );

    // ----------------------------------------------------------------
    // T2: B → A
    // ----------------------------------------------------------------
    log("\n=== T2: B → A ===");
    const t2 = await bridge.send("B", "A", "ping", { seq: 2, from: "B" });
    assert(t2.type === "pong", "T2: A respondeu com pong");
    assert(t2.origin === "A", "T2: origem real da resposta é A");
    assert(t2.destination === "B", "T2: destino da resposta é B");
    assert(
      t2.payload && t2.payload.echo && t2.payload.echo.seq === 2,
      "T2: payload original ecoado corretamente"
    );

    // ----------------------------------------------------------------
    // T3: Simultaneous both directions
    // ----------------------------------------------------------------
    log("\n=== T3: Comunicação simultânea ===");
    const [simA, simB] = await Promise.all([
      bridge.send("A", "B", "echo", { side: "A", n: 42 }),
      bridge.send("B", "A", "echo", { side: "B", n: 99 })
    ]);
    assert(simA.type === "echo" && simA.payload && simA.payload.side === "A", "T3: A→B echo ok");
    assert(simB.type === "echo" && simB.payload && simB.payload.side === "B", "T3: B→A echo ok");
    assert(simA.origin === "B" && simB.origin === "A", "T3: origens das respostas corretas");

    // ----------------------------------------------------------------
    // T4: Invalid messages rejected
    // ----------------------------------------------------------------
    log("\n=== T4: Rejeição de mensagens inválidas ===");
    let t4a = false;
    try {
      await bridge.send("A", "B", "ping", { x: 1 }); // valid — should not throw
      // Force invalid by calling internal path via a malformed envelope through worker
      // We test validateEnvelope directly and also force a bad send path.
      const bad = { protocolVersion: 999, messageId: "x", origin: "A", destination: "B", type: "ping", timestamp: Date.now() };
      const v = validateEnvelope(bad);
      assert(v.valid === false, "T4: protocolVersion inválido rejeitado por validateEnvelope");
      t4a = true;
    } catch (e) {
      log(`T4 helper: ${e.message}`);
    }
    assert(t4a, "T4: validação de protocolVersion funcionou");

    let t4bRejected = false;
    try {
      // type not in ALLOWED_TYPES
      await bridge.send("A", "B", "not_a_real_type", {});
    } catch (e) {
      t4bRejected = true;
      assert(
        String(e.message).includes("Invalid or disallowed type") ||
          String(e.message).includes("not_a_real_type"),
        "T4: tipo desconhecido rejeitado"
      );
    }
    assert(t4bRejected, "T4: envio com type inválido lançou erro");

    const missingFields = validateEnvelope({ origin: "A", destination: "B" });
    assert(missingFields.valid === false, "T4: envelope incompleto rejeitado");

    // ----------------------------------------------------------------
    // T5: Invalid destinations and self-destination
    // ----------------------------------------------------------------
    log("\n=== T5: Destinos inexistentes e self-destination ===");
    let selfRejected = false;
    try {
      await bridge.send("A", "A", "ping", {});
    } catch (e) {
      selfRejected = true;
      assert(
        String(e.message).includes("must differ") || String(e.message).includes("self"),
        "T5: self-destination rejeitado"
      );
    }
    assert(selfRejected, "T5: envio A→A lançou erro");

    const selfEnv = validateEnvelope(
      createEnvelope({ origin: "A", destination: "A", type: "ping" })
    );
    // createEnvelope itself does not block self; validate does
    assert(selfEnv.valid === false, "T5: validateEnvelope rejeita origin === destination");

    let badDest = false;
    try {
      // Directly exercise validation
      const v = validateEnvelope({
        protocolVersion: PROTOCOL_VERSION,
        messageId: "m1",
        origin: "A",
        destination: "C",
        type: "ping",
        timestamp: Date.now()
      });
      assert(v.valid === false, "T5: destination 'C' rejeitado");
      badDest = true;
    } catch (_) {}
    assert(badDest, "T5: destination inexistente tratado");

    // ----------------------------------------------------------------
    // T6: Payload integrity
    // ----------------------------------------------------------------
    log("\n=== T6: Integridade do payload ===");
    const complexPayload = {
      numbers: [1, 2, 3],
      nested: { a: true, b: "hello", c: null },
      unicode: "日本語テスト"
    };
    const t6 = await bridge.send("A", "B", "echo", complexPayload);
    assert(t6.type === "echo", "T6: tipo echo preservado");
    assert(
      JSON.stringify(t6.payload) === JSON.stringify(complexPayload),
      "T6: payload complexo idêntico após ida e volta"
    );

    // ----------------------------------------------------------------
    // T7: Volume test
    // ----------------------------------------------------------------
    log("\n=== T7: Teste de volume ===");
    const VOLUME = 300;
    const volumeStart = performance.now();
    const volumePromises = [];
    for (let i = 0; i < VOLUME; i++) {
      const from = i % 2 === 0 ? "A" : "B";
      const to = from === "A" ? "B" : "A";
      volumePromises.push(
        bridge.send(from, to, "test", { i }, { timeoutMs: 10000 })
      );
    }
    const volumeResults = await Promise.all(volumePromises);
    const volumeMs = performance.now() - volumeStart;
    assert(
      volumeResults.length === VOLUME,
      `T7: ${VOLUME} mensagens enviadas e respondidas`
    );
    assert(
      volumeResults.every((r) => r && r.type === "ack"),
      "T7: todas as respostas são ack"
    );
    log(`T7: ${VOLUME} mensagens em ${volumeMs.toFixed(1)} ms (${(volumeMs / VOLUME).toFixed(2)} ms/msg)`);

    // ----------------------------------------------------------------
    // T8: Bridge does not interfere with emulator commands
    // ----------------------------------------------------------------
    log("\n=== T8: Bridge não interfere nos comandos de emulação ===");
    const beforeA = await workerA.request("stats");
    const beforeB = await workerB.request("stats");

    // Interleave bridge traffic with runFrame
    await Promise.all([
      bridge.send("A", "B", "ping", { during: "frames" }),
      workerA.request("runFrame"),
      workerB.request("runFrame"),
      bridge.send("B", "A", "ping", { during: "frames" })
    ]);

    const afterA = await workerA.request("stats");
    const afterB = await workerB.request("stats");

    assert(
      afterA.frameCounter === beforeA.frameCounter + 1,
      "T8: contador de frames de A avançou exatamente 1 apesar do tráfego da Bridge"
    );
    assert(
      afterB.frameCounter === beforeB.frameCounter + 1,
      "T8: contador de frames de B avançou exatamente 1 apesar do tráfego da Bridge"
    );

    // Extra: setKeys / getKeys still work
    await workerA.request("setKeys", { keys: 0x3 });
    const keysA = await workerA.request("getKeys");
    assert(keysA.keys === 0x3, "T8: setKeys/getKeys continuam funcionando em A");

    await workerB.request("setKeys", { keys: 0x5 });
    const keysB = await workerB.request("getKeys");
    assert(keysB.keys === 0x5, "T8: setKeys/getKeys continuam funcionando em B");

    // ----------------------------------------------------------------
    // Summary
    // ----------------------------------------------------------------
    log("\n========================================");
    log(`TESTES CONCLUÍDOS: ${passed} OK, ${failed} FALHAS`);
    if (failed === 0) {
      log("FASE 0.2.1 — Bridge: TODOS OS TESTES APROVADOS NESTA SESSÃO.", "ok");
    } else {
      log("Há falhas. Verifique o log acima.", "fail");
    }
    log("========================================");
  } catch (error) {
    log(`\nERRO: ${error instanceof Error ? error.message : String(error)}`, "fail");
    log("Os testes seguintes não foram considerados aprovados.", "fail");
    log(`Parcial: ${passed} OK, ${failed} FALHAS até o erro.`);
  } finally {
    runButton.disabled = false;
  }
});
