const logElement = document.querySelector("#log");
const runButton = document.querySelector("#runTests");
const stopButton = document.querySelector("#stopWorkers");
const romAInput = document.querySelector("#romA");
const romBInput = document.querySelector("#romB");

let workers = [];

function log(message) {
  logElement.textContent += `${message}\n`;
}

function assert(condition, message) {
  if (!condition) throw new Error(`FALHOU: ${message}`);
  log(`OK: ${message}`);
}

function makeWorker() {
  const worker = new Worker(
    new URL("../src/workers/emulator.worker.js", import.meta.url),
    { type: "module" }
  );
  let nextId = 1;
  const pending = new Map();

  worker.onmessage = (event) => {
    const message = event.data;
    const item = pending.get(message.id);
    if (!item) return;
    pending.delete(message.id);
    if (message.ok) item.resolve(message);
    else item.reject(new Error(message.error || "Erro não especificado no worker."));
  };

  worker.onerror = (event) => {
    for (const item of pending.values()) item.reject(new Error(event.message));
    pending.clear();
  };

  return {
    raw: worker,
    request(type, payload = {}, transfer = []) {
      const id = nextId++;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        worker.postMessage({ id, type, ...payload }, transfer);
      });
    },
    terminate() {
      worker.terminate();
      for (const item of pending.values()) item.reject(new Error("Worker encerrado."));
      pending.clear();
    }
  };
}

async function readFile(input, fallback) {
  const file = input.files?.[0] || fallback;
  if (!file) throw new Error("Selecione uma ROM GBA para cada worker (ou selecione apenas A para reutilizá-la em B).");
  return file.arrayBuffer();
}

function stopAll() {
  for (const worker of workers) worker.terminate();
  workers = [];
}

stopButton.addEventListener("click", () => {
  stopAll();
  logElement.textContent += "\nWorkers encerrados pelo usuário.\n";
});

runButton.addEventListener("click", async () => {
  runButton.disabled = true;
  stopAll();
  logElement.textContent = "";
  try {
    const romBufferA = await readFile(romAInput);
    const romBufferB = await readFile(romBInput, romAInput.files?.[0]);
    const a = makeWorker();
    const b = makeWorker();
    workers = [a, b];

    const initStart = performance.now();
    const [readyA, readyB] = await Promise.all([
      a.request("init"),
      b.request("init")
    ]);
    log(`A: worker inicializado; memória linear WASM = ${readyA.memoryBytes} bytes.`);
    log(`B: worker inicializado; memória linear WASM = ${readyB.memoryBytes} bytes.`);
    log(`Tempo de inicialização dos dois workers: ${(performance.now() - initStart).toFixed(2)} ms.`);
    assert(a.raw !== b.raw, "foram criados dois Dedicated Workers diferentes");

    await Promise.all([
      a.request("loadRom", { rom: romBufferA }, [romBufferA]),
      b.request("loadRom", { rom: romBufferB }, [romBufferB])
    ]);
    assert(true, "ROM carregada em cada instância mGBA");

    const [frameA, frameB] = await Promise.all([
      a.request("runFrame"),
      b.request("runFrame")
    ]);
    assert(frameA.frameCounter === frameA.beforeFrameCounter + 1 &&
      frameB.frameCounter === frameB.beforeFrameCounter + 1,
      "cada chamada runFrame avançou exatamente um frame em cada instância");
    log(`Contadores após primeiro frame: A=${frameA.frameCounter}; B=${frameB.frameCounter}.`);

    await a.request("setKeys", { keys: 1 });
    const keysA = await a.request("getKeys");
    assert(keysA.keys === 1, "máscara de entrada enviada foi lida de volta pelo core");
    const ewram = 0x02000000;
    await Promise.all([
      a.request("writeMemory8", { address: ewram, value: 0x5a }),
      b.request("writeMemory8", { address: ewram, value: 0xa5 })
    ]);
    const [readA, readB] = await Promise.all([
      a.request("readMemory8", { address: ewram }),
      b.request("readMemory8", { address: ewram })
    ]);
    assert(readA.value === 0x5a, "Worker A leu de volta sua sentinela EWRAM 0x5A");
    assert(readB.value === 0xa5, "Worker B leu de volta sua sentinela EWRAM 0xA5");
    assert(readA.value !== readB.value,
      "a mesma faixa de endereço mantém valores independentes nos dois workers");

    const fb = await a.request("framebuffer");
    assert(fb.width === 240 && fb.height === 160,
      "framebuffer GBA reporta 240×160");
    assert(fb.byteLength === 240 * 160 * 4,
      "framebuffer possui 4 bytes por pixel na configuração nativa de 32 bits");
    log(`Formato declarado pelo wrapper: ${fb.format}.`);

    const framesToBenchmark = 120;
    const [benchA, benchB] = await Promise.all([
      a.request("runFrames", { count: framesToBenchmark }),
      b.request("runFrames", { count: framesToBenchmark })
    ]);
    log(`A: ${framesToBenchmark} frames em ${benchA.durationMs.toFixed(2)} ms; média ${benchA.averageMsPerFrame.toFixed(3)} ms/frame.`);
    log(`B: ${framesToBenchmark} frames em ${benchB.durationMs.toFixed(2)} ms; média ${benchB.averageMsPerFrame.toFixed(3)} ms/frame.`);
    log(`Memória linear WASM final: A=${benchA.memoryBytes} bytes; B=${benchB.memoryBytes} bytes.`);
    assert(benchA.frameCounter >= frameA.frameCounter + framesToBenchmark,
      "contador A avançou durante o lote de benchmark");
    assert(benchB.frameCounter >= frameB.frameCounter + framesToBenchmark,
      "contador B avançou durante o lote de benchmark");

    log("\nTESTES A–G CONCLUÍDOS NESTA SESSÃO DO NAVEGADOR.");
    log("Isso não substitui testes de estabilidade prolongados nem teste em Android.");
  } catch (error) {
    log(`\nERRO: ${error instanceof Error ? error.message : String(error)}`);
    log("Os testes seguintes não foram considerados aprovados.");
  } finally {
    runButton.disabled = false;
  }
});
