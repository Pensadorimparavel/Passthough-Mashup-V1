/**
 * Passthough Mashup V1 — Fase 0.4
 * First real gameplay-data event: Zelda A position -> Bridge -> B acknowledgement.
 * Both emulators remain isolated. No game-memory writes are performed.
 */
import { Bridge } from "../src/bridge/Bridge.js";
import { createEnvelope } from "../src/bridge/MessageProtocol.js";
import { MemoryReader } from "../src/state/memory/MemoryReader.js";
import { ZeldaStateAdapter } from "../src/state/adapters/ZeldaStateAdapter.js";

const $ = (selector) => document.querySelector(selector);
const ui = {
  romA: $("#romA"), romB: $("#romB"), load: $("#load"), stop: $("#stop"),
  sessionStatus: $("#sessionStatus"), canvasA: $("#screenA"), canvasB: $("#screenB"),
  statusA: $("#statusA"), statusB: $("#statusB"), arm: $("#arm"), disarm: $("#disarm"),
  detectStatus: $("#detectStatus"), position: $("#position"), count: $("#count"),
  messageId: $("#messageId"), indicator: $("#indicator"), indicatorTitle: $("#indicatorTitle"),
  indicatorDetail: $("#indicatorDetail"), log: $("#log")
};

const KEY_MASK = Object.freeze({
  a: 1 << 0, b: 1 << 1, select: 1 << 2, start: 1 << 3,
  right: 1 << 4, left: 1 << 5, up: 1 << 6, down: 1 << 7,
  r: 1 << 8, l: 1 << 9
});
const KEY_CODES = new Map([
  ["ArrowUp", "up"], ["ArrowDown", "down"], ["ArrowLeft", "left"], ["ArrowRight", "right"],
  ["KeyX", "a"], ["KeyZ", "b"], ["KeyA", "l"], ["KeyS", "r"],
  ["Enter", "start"], ["ShiftRight", "select"]
]);
const contexts = [ui.canvasA.getContext("2d", { alpha: false }), ui.canvasB.getContext("2d", { alpha: false })];
const imageData = [contexts[0].createImageData(240, 160), contexts[1].createImageData(240, 160)];
let workers = [];
let bridge = null;
let memoryReaderA = null;
let zeldaAdapter = null;
let running = false;
let raf = 0;
let frameBusy = false;
let pressed = new Set();
let currentKeys = 0;
let detectionArmed = false;
let baseline = null;
let stateReadBusy = false;
let lastStateRead = 0;
let eventBusy = false;
let eventCount = 0;

function log(message, cls = "") {
  const line = document.createElement("div");
  if (cls) line.className = cls;
  line.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
  ui.log.appendChild(line);
  ui.log.scrollTop = ui.log.scrollHeight;
}

function makeWorker(label) {
  const raw = new Worker(new URL("../src/workers/emulator.worker.js", import.meta.url), { type: "module" });
  let nextId = 1;
  const pending = new Map();
  let ended = false;
  raw.addEventListener("message", (event) => {
    const message = event.data || {};
    if (message.type === "bridgeOut" || message.type === "bridgeResponse") return;
    const item = pending.get(message.id);
    if (!item) return;
    pending.delete(message.id);
    clearTimeout(item.timeout);
    if (message.ok) item.resolve(message);
    else item.reject(new Error(message.error || `Erro no Worker ${label}.`));
  });
  raw.addEventListener("error", (event) => {
    const error = new Error(event.message || `Falha no Worker ${label}.`);
    for (const item of pending.values()) {
      clearTimeout(item.timeout);
      item.reject(error);
    }
    pending.clear();
    log(error.message, "error");
  });
  return {
    raw,
    request(type, payload = {}, transfer = []) {
      if (ended) return Promise.reject(new Error(`Worker ${label} encerrado.`));
      const id = nextId++;
      return new Promise((resolve, reject) => {
        const timeout = setTimeout(() => {
          pending.delete(id);
          reject(new Error(`Timeout no Worker ${label}: ${type}`));
        }, 12000);
        pending.set(id, { resolve, reject, timeout });
        raw.postMessage({ id, type, ...payload }, transfer);
      });
    },
    terminate() {
      if (ended) return;
      ended = true;
      raw.terminate();
      for (const item of pending.values()) {
        clearTimeout(item.timeout);
        item.reject(new Error(`Worker ${label} encerrado.`));
      }
      pending.clear();
    }
  };
}

function renderFrame(index, frame) {
  if (!(frame.pixels instanceof ArrayBuffer) || frame.width !== 240 || frame.height !== 160) {
    throw new Error(`Framebuffer inválido no Worker ${index === 0 ? "A" : "B"}.`);
  }
  const source = new Uint8Array(frame.pixels);
  const target = imageData[index].data;
  if (source.length < target.length) throw new Error("Framebuffer menor que 240×160.");
  for (let src = 0, dst = 0; dst < target.length; src += 4, dst += 4) {
    target[dst] = source[src];
    target[dst + 1] = source[src + 1];
    target[dst + 2] = source[src + 2];
    target[dst + 3] = 255;
  }
  contexts[index].putImageData(imageData[index], 0, 0);
}

function setPressed(key, down) {
  if (!workers[0] || !KEY_MASK[key]) return;
  if (down) pressed.add(key); else pressed.delete(key);
  let mask = 0;
  for (const value of pressed) mask |= KEY_MASK[value];
  if (mask === currentKeys) return;
  currentKeys = mask;
  workers[0].request("setKeys", { keys: currentKeys }).catch((error) => log(error.message, "error"));
}

function releaseKeys() {
  pressed.clear();
  currentKeys = 0;
  if (workers[0]) workers[0].request("setKeys", { keys: 0 }).catch(() => {});
}

function attachControls() {
  document.querySelectorAll("[data-key]").forEach((button) => {
    const key = button.dataset.key;
    button.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      button.setPointerCapture?.(event.pointerId);
      setPressed(key, true);
    });
    const release = (event) => { event.preventDefault(); setPressed(key, false); };
    button.addEventListener("pointerup", release);
    button.addEventListener("pointercancel", release);
    button.addEventListener("lostpointercapture", () => setPressed(key, false));
    button.addEventListener("contextmenu", (event) => event.preventDefault());
  });
  window.addEventListener("keydown", (event) => {
    const key = KEY_CODES.get(event.code);
    if (!key) return;
    event.preventDefault();
    if (!event.repeat) setPressed(key, true);
  });
  window.addEventListener("keyup", (event) => {
    const key = KEY_CODES.get(event.code);
    if (!key) return;
    event.preventDefault();
    setPressed(key, false);
  });
  window.addEventListener("blur", releaseKeys);
  document.addEventListener("visibilitychange", () => { if (document.hidden) releaseKeys(); });
}

async function readLinkState() {
  if (!zeldaAdapter || stateReadBusy) return null;
  stateReadBusy = true;
  try {
    const state = await zeldaAdapter.readState();
    if (!Number.isFinite(state.position?.x) || !Number.isFinite(state.position?.y)) {
      throw new Error("O Zelda Adapter não retornou X/Y finitos nesta leitura.");
    }
    ui.position.textContent = `X ${state.position.x} · Y ${state.position.y}`;
    return state;
  } finally {
    stateReadBusy = false;
  }
}

async function emitPositionEvent(state) {
  if (!bridge || !workers[0] || eventBusy || !detectionArmed) return;
  const current = { x: state.position.x, y: state.position.y };
  if (!baseline) {
    baseline = current;
    ui.detectStatus.textContent = `Linha de base capturada: X ${current.x}, Y ${current.y}. Mova Link.`;
    return;
  }
  const deltaX = current.x - baseline.x;
  const deltaY = current.y - baseline.y;
  if (deltaX === 0 && deltaY === 0) return;
  eventBusy = true;
  const envelope = createEnvelope({
    origin: "A", destination: "B", type: "link_position_changed",
    payload: { x: current.x, y: current.y, deltaX, deltaY, source: "ZeldaStateAdapter" }
  });
  try {
    const responsePromise = bridge.expectResponse(envelope.messageId, 8000);
    await workers[0].request("bridgeEmit", { envelope });
    const response = await responsePromise;
    if (response.type !== "ack" || response.payload?.received !== true || response.payload?.originalType !== "link_position_changed") {
      throw new Error(`B respondeu sem confirmar o evento: ${JSON.stringify(response.payload)}`);
    }
    eventCount += 1;
    ui.count.textContent = String(eventCount);
    ui.messageId.textContent = envelope.messageId;
    ui.indicator.classList.add("received");
    ui.indicatorTitle.textContent = "B recebeu a mudança de posição";
    ui.indicatorDetail.textContent = `Confirmado pelo Worker B · X ${current.x}, Y ${current.y} · ΔX ${deltaX}, ΔY ${deltaY} · ${new Date(response.payload.receivedAt).toLocaleTimeString()}`;
    ui.detectStatus.textContent = `Evento ${eventCount} confirmado por B.`;
    log(`A → Bridge → B confirmado · ${envelope.messageId} · posição (${current.x}, ${current.y}) · delta (${deltaX}, ${deltaY}).`, "ok");
    baseline = current;
  } catch (error) {
    ui.detectStatus.textContent = `Falha no envio: ${error.message}`;
    log(`Falha no evento A → B: ${error.message}`, "error");
  } finally {
    eventBusy = false;
  }
}

async function pollState() {
  if (!detectionArmed || !running || Date.now() - lastStateRead < 450) return;
  lastStateRead = Date.now();
  try {
    const state = await readLinkState();
    if (state) await emitPositionEvent(state);
  } catch (error) {
    ui.detectStatus.textContent = `Leitura falhou: ${error.message}`;
    log(`Falha ao ler posição de Link: ${error.message}`, "error");
  }
}

async function animationStep() {
  if (!running || frameBusy || workers.length !== 2) return;
  frameBusy = true;
  try {
    const frames = await Promise.all(workers.map((worker) => worker.request("runFrame")));
    const buffers = await Promise.all(workers.map((worker) => worker.request("framebuffer")));
    renderFrame(0, buffers[0]);
    renderFrame(1, buffers[1]);
    ui.statusA.textContent = `Em execução · frame ${frames[0].frameCounter}`;
    ui.statusB.textContent = `Em execução · frame ${frames[1].frameCounter}`;
  } catch (error) {
    log(`Loop de emulação interrompido: ${error.message}`, "error");
    stopLoop();
    ui.sessionStatus.textContent = "Emulação interrompida por erro.";
  } finally {
    frameBusy = false;
  }
  if (running) raf = requestAnimationFrame(animationStep);
}

function startLoop() {
  if (running) return;
  running = true;
  raf = requestAnimationFrame(animationStep);
}

function stopLoop() {
  running = false;
  cancelAnimationFrame(raf);
  releaseKeys();
}

function stopSession() {
  detectionArmed = false;
  baseline = null;
  stopLoop();
  if (bridge) { bridge.destroy(); bridge = null; }
  for (const worker of workers) worker.terminate();
  workers = [];
  memoryReaderA = null;
  zeldaAdapter = null;
  ui.load.disabled = false;
  ui.stop.disabled = true;
  ui.arm.disabled = true;
  ui.disarm.disabled = true;
  ui.sessionStatus.textContent = "Sessão encerrada.";
  ui.statusA.textContent = "Aguardando ROM A.";
  ui.statusB.textContent = "Aguardando ROM B.";
  ui.detectStatus.textContent = "Carregue os dois jogos primeiro.";
  log("Sessão A/B encerrada.");
}

ui.load.addEventListener("click", async () => {
  const fileA = ui.romA.files?.[0];
  const fileB = ui.romB.files?.[0];
  if (!fileA || !fileB) {
    ui.sessionStatus.textContent = "Selecione uma ROM para A e outra para B.";
    return;
  }
  stopSession();
  ui.log.textContent = "";
  ui.load.disabled = true;
  ui.sessionStatus.textContent = "Inicializando dois Workers…";
  try {
    const [bufferA, bufferB] = await Promise.all([fileA.arrayBuffer(), fileB.arrayBuffer()]);
    if (bufferA.byteLength < 0xc0 || bufferB.byteLength < 0xc0) throw new Error("Uma das ROMs é pequena demais para uma ROM GBA válida.");
    const workerA = makeWorker("A");
    const workerB = makeWorker("B");
    workers = [workerA, workerB];
    const ready = await Promise.all([workerA.request("init"), workerB.request("init")]);
    log(`Dois Dedicated Workers inicializados · WASM A ${ready[0].memoryBytes.toLocaleString()} B ${ready[1].memoryBytes.toLocaleString()} bytes.`, "ok");
    await Promise.all([
      workerA.request("loadRom", { rom: bufferA }, [bufferA]),
      workerB.request("loadRom", { rom: bufferB }, [bufferB])
    ]);
    log(`ROM A carregada: ${fileA.name} · ROM B carregada: ${fileB.name}.`, "ok");
    memoryReaderA = new MemoryReader(workerA);
    const memoryReaderB = new MemoryReader(workerB);
    await Promise.all([memoryReaderA.enableReadOnlyPolicy(), memoryReaderB.enableReadOnlyPolicy()]);
    const policies = await Promise.all([memoryReaderA.getWritePolicyState(), memoryReaderB.getWritePolicyState()]);
    if (policies.some((p) => p.memoryWriteEnabled || !p.memoryWriteLocked)) throw new Error("Não foi possível confirmar a trava read-only nos dois Workers.");
    zeldaAdapter = new ZeldaStateAdapter(memoryReaderA);
    bridge = new Bridge(workerA, workerB, {
      onLog: (event) => log(`Bridge ${event.from} → ${event.to} · ${event.type} · ${event.messageId}`),
      onMessage: (event) => log(`Bridge recebeu evento originado em ${event.realOrigin}: ${event.envelope.type}.`),
      onReject: (event) => log(`Bridge rejeitou mensagem: ${event.reason}`, "error")
    });
    const first = await Promise.all([workerA.request("runFrame"), workerB.request("runFrame")]);
    const firstBuffers = await Promise.all([workerA.request("framebuffer"), workerB.request("framebuffer")]);
    renderFrame(0, firstBuffers[0]);
    renderFrame(1, firstBuffers[1]);
    ui.statusA.textContent = `Carregado · frame ${first[0].frameCounter}`;
    ui.statusB.textContent = `Carregado · frame ${first[1].frameCounter}`;
    ui.sessionStatus.textContent = "A e B ativos · Bridge conectada · memória read-only confirmada.";
    ui.stop.disabled = false;
    ui.arm.disabled = false;
    ui.load.disabled = false;
    log("Bridge conectada entre os dois Workers. Nenhuma escrita em RAM está habilitada.", "ok");
    startLoop();
  } catch (error) {
    log(`ERRO ao inicializar Fase 0.4: ${error.message}`, "error");
    ui.sessionStatus.textContent = `Falha: ${error.message}`;
    stopSession();
  } finally {
    ui.load.disabled = false;
  }
});

ui.arm.addEventListener("click", async () => {
  if (!workers.length || !zeldaAdapter) return;
  try {
    const state = await readLinkState();
    if (!state) return;
    baseline = { x: state.position.x, y: state.position.y };
    detectionArmed = true;
    ui.arm.disabled = true;
    ui.disarm.disabled = false;
    ui.detectStatus.textContent = `Detecção armada · base X ${baseline.x}, Y ${baseline.y}. Mova Link para gerar evento.`;
    ui.indicator.classList.remove("received");
    ui.indicatorTitle.textContent = "Aguardando mudança de posição";
    ui.indicatorDetail.textContent = "Linha de base capturada. O próximo deslocamento será enviado ao Worker B.";
    log(`Detecção armada com posição-base (${baseline.x}, ${baseline.y}).`);
  } catch (error) {
    ui.detectStatus.textContent = error.message;
    log(error.message, "error");
  }
});

ui.disarm.addEventListener("click", () => {
  detectionArmed = false;
  baseline = null;
  ui.arm.disabled = false;
  ui.disarm.disabled = true;
  ui.detectStatus.textContent = "Detecção desarmada.";
  log("Detecção desarmada pelo usuário.");
});
ui.stop.addEventListener("click", stopSession);
setInterval(() => { void pollState(); }, 120);
attachControls();
