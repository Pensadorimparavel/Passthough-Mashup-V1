# Fase 0.4 — Primeiro evento funcional A → B

## Objetivo

Detectar uma mudança na posição de Link usando `MemoryReader` + `ZeldaStateAdapter` no Worker A, emitir `link_position_changed` por `bridgeEmit`, encaminhar pelo `Bridge` e confirmar o recebimento no Worker B.

## Arquivos incluídos no overlay

- `src/bridge/MessageProtocol.js` — adiciona `link_position_changed` à lista permitida.
- `src/workers/emulator.worker.js` — valida X/Y e responde com ACK explícito no Worker de destino.
- `tests/phase0_4.html` e `tests/phase0_4.js` — laboratório com duas ROMs, dois Workers, duas telas, controles de Link, detecção manual com posição-base e indicador de confirmação em B.

## Segurança e limites

- Nenhuma escrita em RAM do jogo é executada.
- A política read-only é travada nos dois Workers.
- O Worker B apenas recebe o evento e devolve ACK; não altera Buu's Fury.
- A primeira leitura após armar a detecção vira baseline. Só mudanças posteriores geram eventos.
- X/Y são exatamente os valores retornados pelo ZeldaStateAdapter; não são convertidos em coordenadas de tela.
- O usuário precisa carregar as ROMs localmente no navegador e colocar Zelda em gameplay antes de armar a detecção.

## Instalação no workflow

O overlay precisa ser aplicado depois do Test Lab 0.3.1, porque ele substitui `MessageProtocol.js` e `emulator.worker.js` já presentes no artefato-base. Adicione o ZIP `Passthough_Mashup_V1_Fase_0.4_overlay.zip` ao filtro `push.paths` e aplique seus arquivos como última sobreposição, copiando `src/` e `tests/` para a raiz do workspace.

O teste publicado ficará em `tests/phase0_4.html`. A execução estática de sintaxe não substitui a validação em navegador com as duas ROMs.
